
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('1','2014_01_07_073615_create_tagged_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('2','2014_01_07_073615_create_tags_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('3','2014_10_11_125754_create_currencies_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('4','2014_10_12_000000_create_user_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('5','2014_10_12_000001_update_users_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('6','2016_06_29_073615_create_tag_groups_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('7','2016_06_29_073615_update_tags_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('8','2017_05_06_173745_create_countries_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('9','2019_08_30_072639_create_addresses_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('10','2019_09_21_052540_create_tax_types_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('11','2019_09_21_052548_create_taxes_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('12','2019_11_25_021944_create_customers_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('13','2019_12_14_000001_create_personal_access_tokens_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('14','2020_00_00_000000_create_content_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('15','2020_00_00_000000_create_forms_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('16','2020_00_00_000000_create_notifications_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('17','2020_00_00_000000_create_options_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('18','2020_00_00_000000_create_shop_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('19','2020_00_00_00000_create_permission_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('20','2020_00_00_00001_create_roles_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('21','2020_00_00_00002_create_model_has_permissions_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('22','2020_00_00_00003_create_model_has_roles_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('23','2020_00_00_00004_create_role_has_permissions_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('24','2020_03_13_083515_add_description_to_tags_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('25','2020_10_12_100000_create_password_resets_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('26','2020_10_29_090535_create_jobs_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('27','2020_10_29_090855_create_failed_jobs_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('28','2020_11_12_000000_update_customers_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('29','2021_01_13_100000_create_personal_access_clients','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('30','2021_01_14_000002_update_jobs_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('31','2021_01_19_000000_create_related_content','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('32','2021_01_29_444444_create_translations_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('33','2021_02_09_000000_migrate_en_uk_to_en_gbp','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('34','2021_02_19_000000_add_company_details_addresses_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('35','2021_02_24_000000_insert_countries','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('36','2021_03_04_000001_add_index_to_translation_tables','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('37','2021_03_04_000001_add_index_to_user_table','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('38','2021_02_12_000001_create_translation_keys_table','2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */migrations (id,migration,batch) VALUES('39','2021_02_12_000002_create_translation_texts_table','2'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('4','9','Content','Iwatch','iwatch',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('5','9','Content','Apple','apple',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('6','9','Content','Watch','watch',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('9','10','Content','Jbl','jbl',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('10','10','Content','Speakers','speakers',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('13','11','Content','Apple','apple',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('14','11','Content','Computer','computer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('17','12','Content','Speaker','speaker',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('18','12','Content','Jbl','jbl',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('21','13','Content','Speaker','speaker',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('22','13','Content','Amazon','amazon',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('24','14','Content','Speaker','speaker',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('27','15','Content','Camera','camera',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('28','15','Content','Accessoaries','accessoaries',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('31','17','Content','Diving','diving',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('32','17','Content','Islands','islands',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('34','18','Content','Travel','travel',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('37','18','Content','Usa','usa',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('38','18','Content','West','west',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('42','19','Content','Yacht','yacht',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('43','19','Content','Summer','summer',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('44','19','Content','Sea','sea',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('47','20','Content','Travel','travel',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tagged (id,taggable_id,taggable_type,tag_name,tag_slug,tag_description) VALUES('48','20','Content','World','world',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('1','1','Admin','','94.26.57.98','1','1579615704'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('2','1','Admin','','94.26.57.98','1','1579702189'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('3','1','Admin','','94.26.57.98','1','1580121665'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('4','1','Admin','','94.26.57.98','1','1580295917'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('5','1','Admin','','94.26.57.98','1','1580377667'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('6','1','Admin','','94.26.57.98','1','1580824165'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('7','1','Admin','','94.26.57.98','0','1580901853'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('8','1','Admin','','94.26.57.98','1','1580901857'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('9','1','Admin','','94.26.57.98','1','1581665782'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('10','1','Admin','','94.26.57.98','1','1581694368'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('11','1','Admin','','94.26.57.98','1','1581928162'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('12','1','Admin','','94.26.57.98','1','1582030968'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('13','1','1','1','127.0.0.1','1','1612873867'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('14','1','1','1','127.0.0.1','1','1612955839'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('15','1','1','1','127.0.0.1','1','1612955903'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('16','1','1','1','127.0.0.1','1','1612958690'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('17','1','1','1','127.0.0.1','1','1612960838'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('18','2','John','johndoe@microweber.com','127.0.0.1','1','1612961707'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('19','2','John','johndoe@microweber.com','127.0.0.1','1','1612963928'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('20','2','John','johndoe@microweber.com','127.0.0.1','1','1612964095'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('21','2','John','johndoe@microweber.com','127.0.0.1','1','1612964102'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('22','2','John','johndoe@microweber.com','127.0.0.1','1','1612964116'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('23','2','John','johndoe@microweber.com','127.0.0.1','1','1612964145'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('24','2','John','johndoe@microweber.com','127.0.0.1','1','1612965143'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('25','2','John','johndoe@microweber.com','127.0.0.1','1','1612965897'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('26','2','John','johndoe@microweber.com','127.0.0.1','1','1612965910'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('27','2','John','johndoe@microweber.com','127.0.0.1','1','1612965916'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('28','2','John','johndoe@microweber.com','127.0.0.1','1','1612966059'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('29','2','John','johndoe@microweber.com','127.0.0.1','1','1612966092'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('30','2','John','johndoe@microweber.com','127.0.0.1','1','1612966100'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('31','2','John','johndoe@microweber.com','127.0.0.1','1','1612966104'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('32','2','John','johndoe@testemail.com','127.0.0.1','1','1612968557'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('33','1','1','1','127.0.0.1','1','1614938192'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */login_attempts (id,user_id,username,email,ip,success,time) VALUES('34','1','1','1','127.0.0.1','1','1614938203'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */addresses (id,name,address_street_1,address_street_2,city,state,country_id,zip,phone,fax,type,customer_id,company_id,created_at,updated_at,company_name,company_vat,company_vat_registered) VALUES('1','Default','Cherni Vrah 47','','София','Sofia','','1000','+123456789','','shipping','1','','2021-02-10 12:08:22','2021-02-10 12:08:22','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */addresses (id,name,address_street_1,address_street_2,city,state,country_id,zip,phone,fax,type,customer_id,company_id,created_at,updated_at,company_name,company_vat,company_vat_registered) VALUES('2','Default','Cherni Vruh 47','','Sofia','Sofia','','1000','123456789','','shipping','2','','2021-02-10 13:31:43','2021-02-10 13:31:43','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tax_types (id,name,type,rate,compound_tax,collective_tax,description,company_id,created_at,updated_at) VALUES('1','VAT','percent','20','0','0','','','2021-02-09 13:10:02','2021-02-09 13:10:14'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('1','page','static','home','Home','0','','1','','','1','','','','','index.php','','','','','1','0','0','0','0','','','','pbkxCxYhBnlHEf3vRC2PuMiF0x2olcRBeGJWXJsS','2020-01-30 10:02:47','2020-01-21T10:14:04.000000Z','','','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('2','page','dynamic','blog','Blog','0','','0','','','1','','','','default','layouts__blog.php','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 10:05:51','2020-01-21T10:33:19.000000Z','','1','1','2020-02-17 08:30:46','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('3','post','post','new-version-is-avaliable-for-download','New version is  avaliable for download','22','','1','
                            <div class="element" id="element-3">
    <p class="lead element">Lead text<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<div class="element" id="element-3">
    <p class="element">Regular text<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<div class="element" id="element-3">
    <h2 class="element">Title</h2>
</div>
<div class="element" id="element-3">
    <p class="element">Regular text<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<div class="element" id="element-3">
    <h3 class="element">Title</h3>
</div>
<div class="element" id="element-3">
    <p class="element">Regular text<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<div class="element" id="element-3">
    <div class="safe-mode nodrop element">
        <blockquote class="safe-element">
            Long quote text on the image. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inci didunt ut labore et dolore
            <div class="testimonial">
                <img src="{SITE_URL}userfiles/templates/new-world/assets/img/testimonial.png">
                <span class="name">John Doe</span>
                <span class="info">Manager</span>
            </div>
        </blockquote>
    </div>
</div>
<div class="element" id="element-3">
    <h2 class="element" id="element_1581931741119">Title</h2>
</div>
<div class="element" id="element-3">
    <p class="element" id="element_1581931741120">Regular text<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
</div>
<div class="element" id="element-3">
    <ol class="ol safe-mode nodrop" id="ordered-list-3">
        <li class="cloneable safe-element"><span class="safe-element">Ordered list item 1</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Ordered list item 2</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Ordered list item 3</span></li>
    </ol>
</div>
<div class="element" id="element-3">
    <p class="element">Regular text<br>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
</div>
<div class="element" id="element-3">
    <ul class="ul safe-mode nodrop" id="unordered-list-3">
        <li class="cloneable safe-element"><span class="safe-element">Unordered list item 1</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Unordered list item 2</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Unordered list item 3</span></li>
    </ul>
</div>                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:29:10','2020-01-21T10:33:53.000000Z','','1','1','2020-01-21 10:33:53','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('4','post','post','create-free-website-or-online-store-with-mw','Create free website or online store with MW','22','','1','
                            <div class="element" id="element-4">
    <p class="highlight element" id="element_1579602912513">Inset: short piece of text that needs to be highlighted. De werkopdrachten stapelden zich te veel op om het nog langer louter als bijberoep te doen. </p>
</div>
<div class="element" id="element-4">
    <p class="element" id="element_1579602912514">Inset: short piece of text that needs to be highlighted. De werkopdrachten stapelden zich te veel op om het nog langer louter als bijberoep te doen. </p>
</div>
<div class="element" id="element-4">
    <h2 class="element" id="element_1579602912515">Title</h2>

</div>
<div class="element" id="element-4">
    <p class="element" id="element_1579602912516">Inset: short piece of text that needs to be highlighted. De werkopdrachten stapelden zich te veel op om het nog langer louter als bijberoep te doen. </p>
</div>
<div class="element" id="element-4">
    <h3 class="element" id="element_1581665908104">Title</h3>
</div>
<div class="element" id="element-4">
    <p class="element" id="element_1581665908105">Inset: short piece of text that needs to be highlighted. De werkopdrachten stapelden zich te veel op om het nog langer louter als bijberoep te doen. </p>
</div>
<div class="element" id="element-4">
    <div class="safe-mode nodrop element">
        <blockquote class="safe-element">
            Long quote text on the image. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inci didunt ut labore et dolore
            <div class="testimonial">
                <img src="{SITE_URL}userfiles/templates/new-world/assets/img/testimonial.png">
                <span class="name">Margje Jutten</span>
                <span class="info">Homelesscup</span>
            </div>
        </blockquote>
    </div>
</div>
<div class="element" id="element-4">
    <h2 class="element">Title</h2>
</div>
<div class="element" id="element-4">
    <p class="element">Inset: short piece of text that needs to be highlighted. De werkopdrachten stapelden zich te veel op om het nog langer louter als bijberoep te doen. </p>
</div>
<div class="element" id="element-4">
    <ol class="ol safe-mode nodrop" id="ordered-list-4">
        <li class="cloneable safe-element"><span class="safe-element">Peter Van Bouwel riep in 2006 Pglas in het leven</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Maar was toen al een tijdje in bijberoep aan de slag als<br> installateur van glazen producten.</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Ik kende de stiel al toen ik voltijds met Pglas begon</span></li>
    </ol>
</div>
<div class="element" id="element-4">
    <p class="element">Inset: short piece of text that needs to be highlighted. De werkopdrachten stapelden zich te veel op om het nog langer louter als bijberoep te doen. </p>
</div>
<div class="element" id="element-4">
    <ul class="ul safe-mode nodrop" id="unordered-list-4">
        <li class="cloneable safe-element"><span class="safe-element">Peter Van Bouwel riep in 2006 Pglas in het leven</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Maar was toen al een tijdje in bijberoep aan de slag als<br> installateur van glazen producten.</span></li>
        <li class="cloneable safe-element"><span class="safe-element">Ik kende de stiel al toen ik voltijds met Pglas begon</span></li>
    </ul>
</div>                        ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','340BIUGOYpGnlnKEWsJhjIrNOJoR78TtFDl5ttU6','2020-02-14 07:43:20','2020-01-21T10:33:53.000000Z','','1','1','2020-01-21 10:33:53','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('5','page','static','contact-us','Contact Us','0','','-4','','','1','','','','default','layouts__contacts.php','','','','','0','0','0','0','0','','','','KFir96gCF9PpX8wWUZYyhMuobKNgyj7kyWoH2rI7','2020-02-18 13:03:37','2020-01-22T14:10:12.000000Z','','1','1','2020-01-22 14:10:12','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('6','page','static','about-us','About us','0','','-2','','','1','','','','default','layouts__about.php','','','','','0','0','0','0','0','','','','KFir96gCF9PpX8wWUZYyhMuobKNgyj7kyWoH2rI7','2020-02-18 13:03:50','2020-01-27T10:49:33.000000Z','','1','1','2020-01-27 10:49:33','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('7','page','static','services','Services','0','','-3','','','1','','','','default','layouts__services.php','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 10:05:13','2020-01-29T13:48:15.000000Z','','1','1','2020-01-29 13:48:15','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('8','page','dynamic','shop','Shop','0','','-1','','','1','','','','default','layouts__shop.php','','','','','0','0','1','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2020-02-04 14:12:52','2020-02-04T13:50:17.000000Z','','1','1','2020-02-04 14:12:52','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('9','product','product','modern-golder-watch','Modern Golder Watch','8','','8','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2020-02-04 14:04:05','2020-02-04T13:53:26.000000Z','','1','1','2020-02-04 13:53:26','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('10','product','product','jbl-speaker-wi-fi','JBL speaker WI-FI','8','','7','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2020-02-04 13:56:39','2020-02-04T13:54:38.000000Z','','1','1','2020-02-04 13:54:38','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('11','product','product','apple-computer','Apple Computer','8','','6','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2020-02-04 13:56:23','2020-02-04T13:56:02.000000Z','','1','1','2020-02-04 13:56:02','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('12','product','product','3d-sound-speaker','3D Sound Speaker','8','','5','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2021-03-05 09:58:33','2020-02-04T13:58:24.000000Z','','1','1','2020-02-04 13:58:24','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('13','product','product','amazon-wi-fi-speaker','Amazon WI-FI Speaker','8','','4','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2021-03-05 09:59:02','2020-02-04T13:59:16.000000Z','','1','1','2020-02-04 13:59:16','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('14','product','product','genelec-speaker','Genelec Speaker','8','','3','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2021-03-05 09:59:20','2020-02-04T14:00:18.000000Z','','1','1','2020-02-04 14:00:18','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('15','product','product','camera','Camera','8','','2','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2021-03-05 09:59:42','2020-02-04T14:01:02.000000Z','','1','1','2020-02-04 14:01:02','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('16','page','dynamic','blog-1','Blog','8','','-5','','','1','','','','default','layouts__blog.php','','','','','0','0','0','0','0','','','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','2020-02-04 14:12:52','2020-02-04T14:12:52.000000Z','','1','1','2020-02-04 14:12:52','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('17','post','post','discovery-incommode-earnestly-no-he-commanded','Scuba diving in the islands','2','','9','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:35:13','2020-02-04T16:07:18.000000Z','','1','1','2020-02-04 16:07:18','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('18','post','post','travel-in-the-west','Travel in the west','2','','10','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:34:43','2020-02-04T16:15:34.000000Z','','1','1','2020-02-04 16:15:34','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('19','post','post','unforgettable-summer-vibes','Unforgettable summer vibes','2','','11','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:34:36','2020-02-04T16:18:35.000000Z','','1','1','2020-02-04 16:18:35','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('20','post','post','around-the-world','Around the world','2','','12','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:34:18','2020-02-04T16:20:37.000000Z','','1','1','2020-02-04 16:20:37','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('21','post','post','riding-at-your-favourite-destination','Riding at your favourite destination','2','','13','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:34:09','2020-02-04T16:21:21.000000Z','','1','1','2020-02-04 16:21:21','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('22','page','dynamic','news','News','0','','-5','','','1','','','','default','layouts__blog.php','','','','','0','0','0','0','0','','','','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','2020-02-17 09:28:11','2020-02-04T16:22:23.000000Z','','1','1','2020-02-17 08:50:05','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('8','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('9','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','label','New','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('10','2020-02-04 14:04:05','2020-02-04 13:53:26','1','1','9','label-color','#385dff','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('11','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('12','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('13','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('14','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('15','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('16','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('17','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('18','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('19','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','label','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('20','2020-02-04 13:56:39','2020-02-04 13:54:38','1','1','10','label-color','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('21','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('22','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('23','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('24','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('25','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('26','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('27','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('28','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('29','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','label','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('30','2020-02-04 13:56:23','2020-02-04 13:56:02','1','1','11','label-color','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('31','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('32','2021-03-05 09:58:33','2020-02-04 13:58:24','1','1','12','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('33','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('34','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('35','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('36','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('37','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('38','2020-02-04 14:03:16','2020-02-04 13:58:24','1','1','12','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('39','2020-02-04 14:03:16','2020-02-04 13:58:25','1','1','12','label','Promo','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('40','2020-02-04 14:03:16','2020-02-04 13:58:25','1','1','12','label-color','#d51818','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('41','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('42','2021-03-05 09:59:02','2020-02-04 13:59:16','1','1','13','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('43','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('44','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('45','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('46','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('47','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('48','2020-02-04 13:59:16','2020-02-04 13:59:16','1','1','13','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('49','2021-03-05 09:59:02','2020-02-04 13:59:16','1','1','13','label','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('50','2021-03-05 09:59:02','2020-02-04 13:59:16','1','1','13','label-color','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('51','2020-02-04 14:03:05','2020-02-04 14:00:18','1','1','14','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('52','2021-03-05 09:59:20','2020-02-04 14:00:18','1','1','14','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('53','2020-02-04 14:03:05','2020-02-04 14:00:18','1','1','14','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('54','2020-02-04 14:03:06','2020-02-04 14:00:18','1','1','14','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('55','2020-02-04 14:03:06','2020-02-04 14:00:18','1','1','14','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('56','2020-02-04 14:03:06','2020-02-04 14:00:18','1','1','14','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('57','2020-02-04 14:03:06','2020-02-04 14:00:18','1','1','14','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('58','2020-02-04 14:03:06','2020-02-04 14:00:18','1','1','14','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('59','2021-03-05 09:59:20','2020-02-04 14:00:18','1','1','14','label','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('60','2021-03-05 09:59:20','2020-02-04 14:00:18','1','1','14','label-color','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('61','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','qty','nolimit','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('62','2021-03-05 09:59:42','2020-02-04 14:01:02','1','1','15','sku','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('63','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','shipping_weight','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('64','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','shipping_width','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('65','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','shipping_height','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('66','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','shipping_depth','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('67','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','additional_shipping_cost','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('68','2020-02-04 14:01:02','2020-02-04 14:01:02','1','1','15','max_qty_per_order','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('69','2021-03-05 09:59:42','2020-02-04 14:01:02','1','1','15','label','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('70','2021-03-05 09:59:42','2020-02-04 14:01:02','1','1','15','label-color','','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('71','2021-03-05 09:58:33','2021-03-05 09:58:33','1','1','','special_price','','','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('72','2021-03-05 09:58:33','2021-03-05 09:58:33','1','1','','barcode','','','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('73','2021-03-05 09:59:02','2021-03-05 09:59:02','1','1','','special_price','','','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('74','2021-03-05 09:59:02','2021-03-05 09:59:02','1','1','','barcode','','','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('75','2021-03-05 09:59:20','2021-03-05 09:59:20','1','1','','special_price','','','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('76','2021-03-05 09:59:20','2021-03-05 09:59:20','1','1','','barcode','','','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('77','2021-03-05 09:59:42','2021-03-05 09:59:42','1','1','','special_price','','','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('78','2021-03-05 09:59:42','2021-03-05 09:59:42','1','1','','barcode','','','content','15'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('1','2020-01-30 10:02:47','2020-01-21 10:23:21','1','1','content','1','new-world_content','
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1" template="home-sliders/skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--1" template="skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--1"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--2" template="features/skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--2"></module>
    <module class="module module module-layouts" data-mw-title="Layouts" id="module-layouts-1--3" template="skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--3"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--4" template="features/skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--4"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--5" template="videos/skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--5"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--6" template="skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--6"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--7" template="info-blocks/skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--7"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--8" template="info-blocks/skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--8"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--9" template="skin-7" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--9"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--10" template="info-blocks/skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--10"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--11" template="info-blocks/skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--11"></module>
    <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--12" template="skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--12"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--13" template="info-blocks/skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--13"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--14" template="galleries/skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--14"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--15" template="info-blocks/skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--15"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--16" template="info-blocks/skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--16"></module>
    <module class="module module module-layouts " data-mw-title="Layouts" id="module-layouts-1--17" template="skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--17"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--18" template="blockquotes/skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--18"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--19" template="partners/skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--19"></module>
    <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--20" template="skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--20"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--21" template="features/skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--21"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--22" template="skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--22"></module>
    <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-1--23" template="skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--23"></module>
    <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-1--24" template="skin-8" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-1--24"></module>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('2','2020-01-21 10:23:27','2020-01-21 10:23:21','1','1','module','0','layout-skin-3-module-layouts-1--6','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center allow-drop element" id="element_1579601657561">
                <h2 class="element" id="mw-element_1579601657855">Create a beautiful website easily with Microweber  <br id="mw-br-1579601657756">
</h2>
                <div class="element m-auto" style="max-width: 800px;" id="element_1579601657586">
                    <p class="element" id="mw-element_1579601657936"><br>Microweber is an open-source content management system and website builder. It is based on the PHP programming language and the Laravel 5 web application framework, using drag and drop and allowing users to quickly create content, while scheduling and managing multiple
                        displays.</p>
                    <br>
                    <br>
                </div>
                
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('3','2020-01-21 10:26:20','2020-01-21 10:24:16','1','1','module','0','layout-skin-2-module-layouts-1--12','
    <div class="container" style="max-width:750px;">
        <div class="row">
            <div class="col-12 text-center allow-drop element" id="mw-element_1579601657804">
                <h2 class="hr element" id="mw-element_1579601657805">Travel Around the World</h2>
                <p class="lead element" id="mw-element_1579601657806">Find the best destinations for relax</p>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('4','2020-02-17 10:04:41','2020-01-27 10:50:05','1','1','content','6','new-world_content','
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-6" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6"></module>
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-6--1" template="features/skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--1"></module>
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-6--2" template="galleries/skin-3" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--2"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-6--3" template="contacts/skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--3"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-6--4" template="videos/skin-5" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--4"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-6--5" template="people/skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--5"></module>
<module class="-layout mw-module-drag-clone module module-layouts " data-mw-title="Layouts" template="skin-2.php" data-type="layouts" id="layouts-20200127112745" parent-module="layouts" parent-module-id="layouts-20200127112745"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-6--6" template="people/skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--6"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-6--7" template="blockquotes/skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--7"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-6--8" template="contacts/skin-4" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-6--8"></module>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('5','2020-02-17 10:04:41','2020-01-27 10:50:05','1','1','module','0','layout-skin-9-module-layouts-6','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="m-auto allow-drop element" style="max-width: 800px;" id="element_1581933865969">
                    <h1 class="element" id="mw-element_1581933866078">About us<span class="text-primary">.</span>
</h1>

                    <module class="module module-breadcrumb" id="module-layouts-6-breadcrumb" data-mw-title="Breadcrumb" data-type="breadcrumb" parent-module-id="module-layouts-6" parent-module="layouts"></module>
                    <hr class="hr m-t-0 element" id="element_1581933865979">

                    <p class="lead element" id="mw-element_1581933866145">Our company is established 1992 year. <br>‌We have a great oppinion in working on projects and clients. <br>‌Trust us and read more about us bellow.</p>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('6','2020-01-27 10:50:34','2020-01-27 10:50:34','1','1','module','0','layout-galleries-skin-3-module-layouts-6--2','
    <div class="d-flex w-100">
        <div class="container align-self-centerx">
            <div class="row">
                <div class="col-12 col-xl-10 mx-auto text-center">
                    <h2 class="m-b-30">Our Projects Gallery</h2>
                    <p class="lead">It is a long established fact that a reader will be distracted by the readable <br>content of a page when looking at its layout.</p>
                    <br>

                    <module class="module module-pictures" id="module-layouts-6--2-pictures" data-mw-title="Picture Gallery" template="skin-7" data-type="pictures" parent-module-id="module-layouts-6--2" parent-module="layouts"></module>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('7','2020-01-27 10:56:47','2020-01-27 10:50:34','1','1','module','0','layout-contacts-skin-2-module-layouts-6--3','
    <div class="container">
        <div class="row">
            <div class="col-xl-10 mx-auto">
                <div class="row">
                    <div class="col-xl-6 text-center text-lg-left m-b-40 allow-drop element" id="mw-element_1580122175979">
                        <h2 class="hr element" id="mw-element_1580122175980">Why Choose Us?</h2>
                        <p class="element" id="mw-element_1580122175981">Microweber is an open-source content management system and website builder.
                            It is based on the PHP programming language and the Laravel 5 web application framework, using drag and drop and allowing users to quickly create content, while scheduling and managing multiple displays.</p>
                        <br>
                        <br>

                        <div class="element" id="mw-element_1580122175982">
                            <module class=" module module-btn " id="module-layouts-6--3-btn" data-mw-title="Button" template="bootstrap" button_style="btn-primary" button_text="Contact Us" data-type="btn" parent-module-id="module-layouts-6--3" parent-module="layouts"></module>
                        </div>
                    </div>

                    <div class="col-xl-5 offset-xl-1">
                        <div class="row">
                            <div class="col-12 cloneable">
                                <div class="shadow-md box">
                                    <div class="icon-holder">
                                        <i class="mw-icon mw-micon-Building"></i>
                                    </div>
                                    <div class="text-holder allow-drop element" id="mw-element_1580122175983">
                                        <p class="element" id="mw-element_1580122175984"><strong>Easy solution</strong></p>
                                        <p class="element" id="mw-element_1580122175985">Lorem Ipsum is simply dummy text of the printing</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 cloneable">
                                <div class="shadow-md box">
                                    <div class="icon-holder">
                                        <i class="mw-icon mw-micon-Smartphone-3"></i>
                                    </div>
                                    <div class="text-holder allow-drop element" id="mw-element_1580122175986">
                                        <p class="element" id="mw-element_1580122175987"><strong>Easy solution</strong></p>
                                        <p class="element" id="mw-element_1580122175988">Lorem Ipsum is simply dummy text of the printing</p>
                                    </div>
                                </div>
                            </div>

                            <div class="col-12 cloneable">
                                <div class="shadow-md box">
                                    <div class="icon-holder">
                                        <i class="mw-icon mw-micon-Email"></i>
                                    </div>
                                    <div class="text-holder allow-drop element" id="mw-element_1580122175989">
                                        <p class="element" id="mw-element_1580122175990"><strong>Easy solution</strong></p>
                                        <p class="element" id="mw-element_1580122175991">Lorem Ipsum is simply dummy text of the printing</p>
                                    </div>

                                    <div class="socials-holder">
                                        <module class="module module-social-links" id="module-layouts-6--3-social-links" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--3" parent-module="layouts"></module>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('8','2020-01-27 10:58:56','2020-01-27 10:58:56','1','1','module','0','layout-people-skin-1-module-layouts-6--5','
    <div class="d-flex w-100">
        <div class="container align-self-centerx">
            <div class="row">
                <div class="col-xl-8 col-lg-8 text-center m-b-20 mx-auto">
                    <h1 class="m-b-10">Our Team</h1>
                    <p class="lead">It is a long established fact that a reader will be distracted by the readable <br>content of a page when looking at its layout. </p>
                    <hr class="hr">
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-lg-12 col-xl-10 mx-auto">
                    <div class="row text-center text-white">
                        <div class="col-12 col-sm-6 col-md-4 cloneable">
                            <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/new-world/assets/img/people-1.jpg&rsquo;);" id="mw-element_1580122175997">
                                <div class="square">
                                    <div class="content allow-drop element" id="mw-element_1580122175998">
                                        <h5 class="element" id="mw-element_1580122175999">Charley Doe</h5>
                                        <p class="m-t-10 element" id="mw-element_1580122176000">Charley is a senior developer in our company. He is doing great code and software solutions. Educated in Sofia, Bulgaria.</p>

                                        <div class="element socials-holder" id="mw-element_1580122176001">
                                            <module class="module module-social-links" id="module-layouts-6--5-social-links" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--5" parent-module="layouts"></module>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 cloneable">
                            <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/new-world/assets/img/people-2.jpg&rsquo;);" id="mw-element_1580122176002">
                                <div class="square">
                                    <div class="content allow-drop element" id="mw-element_1580122176003">
                                        <h5 class="element" id="mw-element_1580122176004">Charley Doe</h5>
                                        <p class="m-t-10 element" id="mw-element_1580122176005">Charley is a senior developer in our company. He is doing great code and software solutions. Educated in Sofia, Bulgaria.</p>

                                        <div class="element socials-holder" id="mw-element_1580122176006">
                                            <module class="module module-social-links" id="module-layouts-6--5-social-links--1" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--5" parent-module="layouts"></module>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 cloneable">
                            <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/new-world/assets/img/people-3.jpg&rsquo;);" id="mw-element_1580122176007">
                                <div class="square">
                                    <div class="content allow-drop element" id="mw-element_1580122176008">
                                        <h5 class="element" id="mw-element_1580122176009">Charley Doe</h5>
                                        <p class="m-t-10 element" id="mw-element_1580122176010">Charley is a senior developer in our company. He is doing great code and software solutions. Educated in Sofia, Bulgaria.</p>

                                        <div class="element socials-holder" id="mw-element_1580122176011">
                                            <module class=" module module-social-links " id="module-layouts-6--5-social-links--2" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--5" parent-module="layouts"></module>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 cloneable">
                            <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/new-world/assets/img/people-4.jpg&rsquo;);" id="mw-element_1580122176012">
                                <div class="square">
                                    <div class="content allow-drop element" id="mw-element_1580122176013">
                                        <h5 class="element" id="mw-element_1580122176014">Charley Doe</h5>
                                        <p class="m-t-10 element" id="mw-element_1580122176015">Charley is a senior developer in our company. He is doing great code and software solutions. Educated in Sofia, Bulgaria.</p>

                                        <div class="element socials-holder" id="mw-element_1580122176016">
                                            <module class=" module module-social-links " id="module-layouts-6--5-social-links--3" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--5" parent-module="layouts"></module>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 cloneable">
                            <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/new-world/assets/img/people-5.jpg&rsquo;);" id="mw-element_1580122176017">
                                <div class="square">
                                    <div class="content allow-drop element" id="mw-element_1580122176018">
                                        <h5 class="element" id="mw-element_1580122176019">Charley Doe</h5>
                                        <p class="m-t-10 element" id="mw-element_1580122176020">Charley is a senior developer in our company. He is doing great code and software solutions. Educated in Sofia, Bulgaria.</p>

                                        <div class="element socials-holder" id="mw-element_1580122176021">
                                            <module class=" module module-social-links " id="module-layouts-6--5-social-links--4" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--5" parent-module="layouts"></module>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12 col-sm-6 col-md-4 cloneable">
                            <div class="background-image-holder element" style="background-image: url(&rsquo;{SITE_URL}userfiles/templates/new-world/assets/img/people-6.jpg&rsquo;);" id="mw-element_1580122176022">
                                <div class="square">
                                    <div class="content allow-drop element" id="mw-element_1580122176023">
                                        <h5 class="element" id="mw-element_1580122176024">Charley Doe</h5>
                                        <p class="m-t-10 element" id="mw-element_1580122176025">Charley is a senior developer in our company. He is doing great code and software solutions. Educated in Sofia, Bulgaria.</p>

                                        <div class="element socials-holder" id="mw-element_1580122176026">
                                            <module class=" module module-social-links " id="module-layouts-6--5-social-links--5" data-mw-title="Social Links" data-type="social_links" parent-module-id="module-layouts-6--5" parent-module="layouts"></module>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('9','2020-01-27 11:08:25','2020-01-27 11:08:25','1','1','module','0','layout-people-skin-2-module-layouts-6--6','
    <div class="d-flex w-100">
        <div class="container align-self-centerx">
            <div class="row">
                <div class="col-xl-8 col-lg-8 text-center m-b-20 mx-auto">
                    <h1 class="m-b-10">Our Team</h1>
                    <p class="lead">It is a long established fact that a reader will be distracted. </p>
                    <hr class="hr">
                </div>
            </div>

            <div class="row">
                <div class="col-xl-10 mx-auto">
                    <module class="module module-teamcard" id="module-layouts-6--6-teamcard" data-mw-title="Team Card" template="skin-2" data-type="teamcard" parent-module-id="module-layouts-6--6" parent-module="layouts"></module>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('10','2020-01-27 11:28:48','2020-01-27 11:27:56','1','1','module','0','layout-skin-2-layouts-20200127112745','
    <div class="container" style="max-width:750px;">
        <div class="row">
            <div class="col-12 text-center allow-drop element" id="mw-element_1580124507247">
                
                <p class="lead element" id="mw-element_1580124507305">We will work together for your creative project  <br><br id="mw-br-1580124507296"></p>
<module class="-module module-cat-toggle-Modules mw-module-drag-clone module module-btn" data-mw-title="Button" data-type="btn" id="btn-20200127112839" parent-module="btn" parent-module-id="btn-20200127112839"></module>
<br>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('11','2020-01-27 11:35:25','2020-01-27 11:35:25','1','1','module','0','layout-blockquotes-skin-4-module-layouts-6--7','
    <div class="d-flex w-100">
        <div class="container align-self-centerx">
            <div class="row">
                <div class="col-xl-8 col-lg-8 text-center m-b-20 mx-auto">
                    <h1 class="m-b-10">Clients Opinions</h1>
                    <p class="lead">Read what our lients says for our services.  <br><br id="mw-br-1580124507842"></p>
                </div>
            </div>

            <div class="row">
                <div class="col-xl-10 mx-auto">
                    <module class="module module-testimonials" id="module-layouts-6--7-testimonials" data-mw-title="Testimonials" template="skin-2" data-type="testimonials" parent-module-id="module-layouts-6--7" parent-module="layouts"></module>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('12','2020-01-27 11:51:15','2020-01-27 11:50:31','1','1','module','0','layout-videos-skin-5-module-layouts-1--5','
    <div class="d-flex w-100">
        <div class="container align-self-center info-holder">
            <div class="row">
                <div class="col-12 mx-auto">
                    <div class="row">
                        <div class="offset-xl-2 col-xl-3 info-holder allow-drop element" id="element_1580125749137">
                            
                            <h2 class="m-b-30 element" id="mw-element_1580125749377">Some title for <br>the video <br>section here</h2>
                            <p class="element" id="element_1580125749120">Microweber is an open-source content management system and website builder and drag and drop CMS. </p>
                            <div class="element m-t-40" id="mw-element_1580125749288">
                                <module class="module module module-btn" data-mw-title="Button" id="module-layouts-1--5-btn" template="bootstrap" text="Contact Us" button_style="btn-primary" data-type="btn" parent-module-id="module-layouts-1--5" parent-module="layouts"></module>
                            </div>
                        </div>

                        <div class="col-sm-10 mx-sm-auto col-xl-6 video-holder">
                            <module class="module module-video" id="module-layouts-1--5-video" data-mw-title="Video" url="https://vimeo.com/98679934" data-type="video" parent-module-id="module-layouts-1--5" parent-module="layouts"></module>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('13','2020-02-17 10:05:13','2020-01-29 13:49:17','1','1','content','7','new-world_content','
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-7" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7"></module>
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-7--1" template="features/skin-10" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7--1"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-7--2" template="skin-10" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7--2"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-7--3" template="videos/skin-6" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7--3"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-7--4" template="pricing/skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7--4"></module>
        <module class=" module module-layouts " data-mw-title="Layouts" id="module-layouts-7--5" template="cta/skin-2" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-7--5"></module>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('14','2020-02-17 10:05:13','2020-01-29 13:49:17','1','1','module','0','layout-skin-9-module-layouts-7','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="m-auto allow-drop element" style="max-width: 800px;" id="mw-element_1581933898838">
                    <h1 class="element" id="mw-element_1581933898839">Services<span class="text-primary">.</span>
</h1>

                    <module class=" module module-breadcrumb " id="module-layouts-7-breadcrumb" data-mw-title="Breadcrumb" data-type="breadcrumb" parent-module-id="module-layouts-7" parent-module="layouts"></module>
                    <hr class="hr m-t-0 element" id="mw-element_1581933898840">

                    <p class="lead element" id="mw-element_1581933898938">Professional developers can freely access the code, <br>‌exchanging 
their knowledge and contributions <br>‌with the rest of the 
open-source community</p>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('15','2020-01-30 10:01:04','2020-01-30 10:01:04','1','1','module','0','layout-skin-3-module-layouts-1--17','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center allow-drop element" id="element_1580378301807">
                <h2 class="hr element" id="element_1580378301893">What our clients says?</h2>
                
                
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('16','2020-01-30 10:02:04','2020-01-30 10:02:04','1','1','module','0','layout-skin-3-module-layouts-1--20','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center allow-drop element" id="element_1580378302152">
                <h2 class="hr element" id="element_1580378302162">Our Awesome Core Features
</h2>
                <div class="element m-auto" style="max-width: 800px;" id="element_1580378302233">
                    <p class="element" id="mw-element_1580378302489">There are countless reasons why our service is better than the rest, <br>but here you can learn about why we’re different.











</p>
                    <br>
                </div>
                
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('17','2020-01-30 10:02:47','2020-01-30 10:02:47','1','1','module','0','layout-skin-3-module-layouts-1--22','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center allow-drop element" id="mw-element_1580378302474">
                <h2 class="hr element" id="mw-element_1580378302475">Let’s meet together on</h2>
                
                
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('18','2020-02-04 14:02:25','2020-02-04 14:02:20','1','1','content','8','new-world_content','
    <module class="module module-layouts" id="module-layouts-8" data-mw-title="Layouts" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-8"></module>

    <div class="container safe-mode nodrop">
        <div class="row">
            <div class="col-xl-12 mx-auto">
                <div class="row justify-content-between">
                    <div class="col-9">
                        <module class="module module-shop-products" id="module-shop-products-8" data-mw-title="Products" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-8"></module>
                    </div>
                    <div class="col-2">
                        <div class="edit allow-drop element" field="active_shop_sidebar" rel="inherit">
    <div class="sidebar element" id="element_1580824914312">
        <div class="sidebar__widget search-holder element">
            <module class=" module module-search " id="module-search-8" data-mw-title="Search" data-search-type="shop" data-type="search" parent-module="search" parent-module-id="module-search-8"></module>
        </div>

        <div class="sidebar__widget m-b-40 element" id="element_1580824914174">
            <h4 class="m-b-20 element" id="element_1580824914263">Categories</h4>

            <module class="module module-categories" id="module-categories-8" data-mw-title="Categories" template="skin-1" content-id="8" data-type="categories" parent-module="categories" parent-module-id="module-categories-8"></module>
        </div>

        <div class="sidebar__widget m-b-40 element" id="element_1580824914314">
            <h4 class="m-b-20 element" id="element_1580824914313">Tags</h4>

            <module class="module module-tags" id="module-tags-8" data-mw-title="Tags" template="skin-1" data-type="tags" parent-module="tags" parent-module-id="module-tags-8"></module>
        </div>

        <div class="sidebar__widget m-b-40 element">
            <h4 class="m-b-20 element">About Us</h4>
            <p class="element">
                We&rsquo;re a digital focussed collective working with individuals and businesses to establish rich, engaging online presences.            </p>
        </div>
    </div>
</div>


                    </div>
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('19','2020-02-17 10:05:42','2020-02-04 14:02:20','1','1','module','0','layout-skin-9-module-layouts-8','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="m-auto allow-drop element" style="max-width: 800px;" id="element_1581933933637">
                    <h1 class="element" id="element_1581933933659">Shop<span class="text-primary">.</span>
</h1>

                    <module class="module module-breadcrumb" id="module-layouts-8-breadcrumb" data-mw-title="Breadcrumb" data-type="breadcrumb" parent-module-id="module-layouts-8" parent-module="layouts"></module>
                    <hr class="hr m-t-0 element">

                    
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('20','2020-02-04 14:11:28','2020-02-04 14:11:28','1','1','inherit','8','related_products','
                            <div class="row m-t-20">
                                <div class="col-12 text-left">
                                    <h5 class="hr">Related products</h5>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <module class="module module module-shop-products" data-mw-title="Products" id="module-shop-products-13" template="skin-1" related="true" limit="6" hide_paging="true" data-type="shop/products" parent-module="shop/products" parent-module-id="module-shop-products-13"></module>
                                </div>
                            </div>
                        '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('21','2020-02-17 10:05:51','2020-02-04 15:52:25','1','1','content','2','new-world_content','
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-2" template="skin-9" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-2"></module>
        <module class="module module-layouts" data-mw-title="Layouts" id="module-layouts-2--1" template="posts/skin-1" data-type="layouts" parent-module="layouts" parent-module-id="module-layouts-2--1"></module>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('22','2020-02-17 09:28:11','2020-02-14 07:42:51','1','1','page','22','blog-inner',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('23','2020-02-17 10:05:51','2020-02-17 08:47:55','1','1','module','0','layout-skin-9-module-layouts-2','
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <div class="m-auto allow-drop element" style="max-width: 800px;" id="element_1581933944976">
                    <h1 class="element">Blog<span class="text-primary">.</span>
</h1>

                    <module class=" module module-breadcrumb " id="module-layouts-2-breadcrumb" data-mw-title="Breadcrumb" data-type="breadcrumb" parent-module-id="module-layouts-2" parent-module="layouts"></module>
                    <hr class="hr m-t-0 element">

                    
                </div>
            </div>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('24','2020-02-17 08:47:55','2020-02-17 08:47:55','1','1','module','0','layout-posts-skin-1-module-layouts-2--1','
    <div class="container allow-drop element" id="element_1581929257366">
        <div class="row element nodrop">
            
        </div>

        <module class="module module-posts" id="module-layouts-2--1-posts" data-mw-title="Posts List" template="blog" data-type="posts" parent-module-id="module-layouts-2--1" parent-module="layouts"></module>

    </div>
'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('1','2020-01-27 11:05:32','2020-01-27T11:05:32.000000Z','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','modules','module-layouts-6--2-pictures','picture','1','','','','{SITE_URL}userfiles/media/templates.microweber.com/1-94.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('2','2020-01-27 11:05:32','2020-01-27T11:05:32.000000Z','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','modules','module-layouts-6--2-pictures','picture','2','','','','{SITE_URL}userfiles/media/templates.microweber.com/18-38.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('3','2020-01-27 11:05:32','2020-01-27T11:05:32.000000Z','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','modules','module-layouts-6--2-pictures','picture','0','','','','{SITE_URL}userfiles/media/templates.microweber.com/20-35.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('4','2020-02-04 13:52:59','2020-02-04T13:52:59.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9','picture','0','','','','{SITE_URL}userfiles/media/templates.microweber.com/7__48004.1557125030.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('5','2020-02-04 13:54:36','2020-02-04T13:54:36.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/2__69884.1557124343.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('6','2020-02-04 13:54:36','2020-02-04T13:54:36.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/16__95752.1557125556.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('7','2020-02-04 13:55:58','2020-02-04T13:55:58.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/5__85794.1557124344.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('8','2020-02-04 13:56:20','2020-02-04T13:56:20.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/1__43193.1557124343.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('9','2020-02-04 13:56:20','2020-02-04T13:56:20.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/2__69884.1557124343_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('10','2020-02-04 13:56:20','2020-02-04T13:56:20.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/11__49143.1557125318.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('11','2020-02-04 13:56:20','2020-02-04T13:56:20.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','11','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/16__95752.1557125556_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('12','2020-02-04 13:56:34','2020-02-04T13:56:34.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/1__43193.1557124343_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('13','2020-02-04 13:56:34','2020-02-04T13:56:34.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/16__95752.1557125556_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('14','2020-02-04 13:56:38','2020-02-04T13:56:38.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','10','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/2__69884.1557124343_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('15','2020-02-04 13:56:55','2020-02-04T13:56:55.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9','picture','2','','','','{SITE_URL}userfiles/media/templates.microweber.com/7__48004.1557125030_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('16','2020-02-04 13:56:55','2020-02-04T13:56:55.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9','picture','1','','','','{SITE_URL}userfiles/media/templates.microweber.com/12__41534.1557125318.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('17','2020-02-04 13:57:06','2020-02-04T13:57:06.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/12__41534.1557125318_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('18','2020-02-04 13:57:52','2020-02-04T13:57:52.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12','picture','1','','','','{SITE_URL}userfiles/media/templates.microweber.com/1__43193.1557124343_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('19','2020-02-04 13:57:52','2020-02-04T13:57:52.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12','picture','2','','','','{SITE_URL}userfiles/media/templates.microweber.com/2__69884.1557124343_3.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('20','2020-02-04 13:57:52','2020-02-04T13:57:52.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12','picture','3','','','','{SITE_URL}userfiles/media/templates.microweber.com/9__68359.1557125030.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('21','2020-02-04 13:57:52','2020-02-04T13:57:52.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12','picture','4','','','','{SITE_URL}userfiles/media/templates.microweber.com/13__85251.1557125318.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('22','2020-02-04 13:57:53','2020-02-04T13:57:53.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12','picture','0','','','','{SITE_URL}userfiles/media/templates.microweber.com/14__82429.1557125318.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('23','2020-02-04 13:57:53','2020-02-04T13:57:53.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','12','picture','5','','','','{SITE_URL}userfiles/media/templates.microweber.com/16__95752.1557125556_3.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('24','2020-02-04 13:59:04','2020-02-04T13:59:04.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/1__43193.1557124343_3.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('25','2020-02-04 13:59:04','2020-02-04T13:59:04.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/2__69884.1557124343_4.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('26','2020-02-04 13:59:04','2020-02-04T13:59:04.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/9__68359.1557125030_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('27','2020-02-04 13:59:04','2020-02-04T13:59:04.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/13__85251.1557125318_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('28','2020-02-04 13:59:04','2020-02-04T13:59:04.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','13','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/16__95752.1557125556_4.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('29','2020-02-04 13:59:48','2020-02-04T13:59:48.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14','picture','1','','','','{SITE_URL}userfiles/media/templates.microweber.com/1__43193.1557124343_4.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('30','2020-02-04 13:59:48','2020-02-04T13:59:48.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14','picture','2','','','','{SITE_URL}userfiles/media/templates.microweber.com/2__69884.1557124343_5.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('31','2020-02-04 13:59:48','2020-02-04T13:59:48.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14','picture','3','','','','{SITE_URL}userfiles/media/templates.microweber.com/9__68359.1557125030_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('32','2020-02-04 13:59:48','2020-02-04T13:59:48.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14','picture','0','','','','{SITE_URL}userfiles/media/templates.microweber.com/13__85251.1557125318_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('33','2020-02-04 13:59:49','2020-02-04T13:59:49.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14','picture','4','','','','{SITE_URL}userfiles/media/templates.microweber.com/14__82429.1557125318_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('34','2020-02-04 13:59:49','2020-02-04T13:59:49.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','14','picture','5','','','','{SITE_URL}userfiles/media/templates.microweber.com/16__95752.1557125556_5.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('35','2020-02-04 14:00:46','2020-02-04T14:00:46.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/4__71728.1557124344.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('36','2020-02-04 14:00:46','2020-02-04T14:00:46.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/6__63475.1557125030.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('37','2020-02-04 14:00:46','2020-02-04T14:00:46.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/10__66837.1557125165.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('38','2020-02-04 14:00:46','2020-02-04T14:00:46.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/11__49143.1557125318_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('39','2020-02-04 14:00:46','2020-02-04T14:00:46.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','15','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/14__82429.1557125318_2.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('41','2020-02-04 15:49:42','2020-02-04T15:49:42.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','4','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/website_whmcs_microweber-v2_1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('43','2020-02-04 16:13:53','2020-02-04T16:13:53.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','17','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/homepage-default-banner.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('44','2020-02-04 16:15:27','2020-02-04T16:15:27.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','18','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/blog-image-1.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('45','2020-02-04 16:17:09','2020-02-04T16:17:09.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','19','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/blog-detail.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('46','2020-02-04 16:20:23','2020-02-04T16:20:23.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','20','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/cruises-result.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('47','2020-02-04 16:20:46','2020-02-04T16:20:46.000000Z','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','content','21','picture','9999999','','','','{SITE_URL}userfiles/media/templates.microweber.com/bg-section-team.jpg',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('48','2021-02-09 12:31:17','2021-02-09T12:31:17.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-cb010cb765eb5b458d32a984ae0906b6','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":160,"height":160,"cache_path_relative":"cache\\thumbnails\\160\\tn-cb010cb765eb5b458d32a984ae0906b6.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('49','2021-02-09 12:31:17','2021-02-09T12:31:17.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c5644a5630c7f4fe3babbe6958145434','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-c5644a5630c7f4fe3babbe6958145434.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('50','2021-02-09 12:33:29','2021-02-09T12:33:29.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b4f8846b19cf4a5f2d26eeca0cba2c3a','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-b4f8846b19cf4a5f2d26eeca0cba2c3a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('51','2021-02-09 12:34:15','2021-02-09T12:34:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-9dc3edabae7373f7213fc5b774b9a84d','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-9dc3edabae7373f7213fc5b774b9a84d.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('52','2021-02-09 12:34:15','2021-02-09T12:34:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-87fb60240fa1ba15738618db10a1ec7f','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-87fb60240fa1ba15738618db10a1ec7f.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('53','2021-02-09 12:34:16','2021-02-09T12:34:16.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-228ee058ab440211d9155c4224b8e1da','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/5__85794.1557124344.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/5__85794.1557124344.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-228ee058ab440211d9155c4224b8e1da.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('54','2021-02-09 12:34:16','2021-02-09T12:34:16.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-941ad7a14e6fe3032dad9c34f8680493','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/14__82429.1557125318.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/14__82429.1557125318.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-941ad7a14e6fe3032dad9c34f8680493.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('55','2021-02-09 12:34:16','2021-02-09T12:34:16.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-391ae5bd84a6100279c6f497f548355a','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1__43193.1557124343_3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1__43193.1557124343_3.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-391ae5bd84a6100279c6f497f548355a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('56','2021-02-09 12:34:16','2021-02-09T12:34:16.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-272a8f50cc16f1d9aef589a496a1fe16','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-272a8f50cc16f1d9aef589a496a1fe16.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('57','2021-02-09 12:34:16','2021-02-09T12:34:16.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-55ef5bde05af770f0be2fa037b142a86','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/4__71728.1557124344.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/4__71728.1557124344.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-55ef5bde05af770f0be2fa037b142a86.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('58','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-1da6fc26ed6c1761b2e2d13f8a7d2dd1','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/20-35.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/20-35.jpg","width":450,"height":320,"crop":true,"cache_path_relative":"cache\\thumbnails\\450\\tn-1da6fc26ed6c1761b2e2d13f8a7d2dd1.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('59','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c0d78eb8f00aa58237fd3d4d7806d69a','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1-94.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1-94.jpg","width":450,"height":320,"crop":true,"cache_path_relative":"cache\\thumbnails\\450\\tn-c0d78eb8f00aa58237fd3d4d7806d69a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('60','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-12b36b0dceafdb4b79a73cb944c72470','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/18-38.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/18-38.jpg","width":450,"height":320,"crop":true,"cache_path_relative":"cache\\thumbnails\\450\\tn-12b36b0dceafdb4b79a73cb944c72470.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('61','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-df3e4d86a7ba91563483ac97ad615730','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/20-35.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/20-35.jpg","width":1200,"height":0,"cache_path_relative":"cache\\thumbnails\\1200\\tn-df3e4d86a7ba91563483ac97ad615730.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('62','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c084d50450d145fa1858881fd645a600','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1-94.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1-94.jpg","width":1200,"height":0,"cache_path_relative":"cache\\thumbnails\\1200\\tn-c084d50450d145fa1858881fd645a600.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('63','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-e62dea76f298c0e3a94cbfedbf79c7d3','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/18-38.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/18-38.jpg","width":1200,"height":0,"cache_path_relative":"cache\\thumbnails\\1200\\tn-e62dea76f298c0e3a94cbfedbf79c7d3.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('64','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-d575179795c937cf544159c591a1b29d','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/people-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/people-1.jpg","width":400,"height":400,"crop":true,"cache_path_relative":"cache\\thumbnails\\400\\tn-d575179795c937cf544159c591a1b29d.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('65','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-6a1247af43e790ddcdcc1f9a5c978425','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/people-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/people-2.jpg","width":400,"height":400,"crop":true,"cache_path_relative":"cache\\thumbnails\\400\\tn-6a1247af43e790ddcdcc1f9a5c978425.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('66','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-f58f4d391030457282b4e216bd48b418','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/people-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/people-4.jpg","width":400,"height":400,"crop":true,"cache_path_relative":"cache\\thumbnails\\400\\tn-f58f4d391030457282b4e216bd48b418.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('67','2021-02-09 12:35:12','2021-02-09T12:35:12.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-ddaf0969b32ab8ee56fe06605e8cdc4e','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/people-3_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/people-3_1.jpg","width":400,"height":400,"crop":true,"cache_path_relative":"cache\\thumbnails\\400\\tn-ddaf0969b32ab8ee56fe06605e8cdc4e.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('68','2021-02-09 12:35:13','2021-02-09T12:35:13.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-abcb5f44e45a02b6c812b8facad1461e','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/team3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/team3.jpg","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-abcb5f44e45a02b6c812b8facad1461e.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('69','2021-02-09 12:35:13','2021-02-09T12:35:13.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c7f04d0356ba84662f85d12b8dc68902','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/team1_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/team1_1.jpg","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-c7f04d0356ba84662f85d12b8dc68902.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('70','2021-02-09 12:35:13','2021-02-09T12:35:13.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-351d62ff1d479d458c83aee3a7bc7286','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/team2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/team2.jpg","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-351d62ff1d479d458c83aee3a7bc7286.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('71','2021-02-09 12:35:13','2021-02-09T12:35:13.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-ce5483a2cf8229fc972bc8ad171c33c4','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/team6.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/team6.jpg","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-ce5483a2cf8229fc972bc8ad171c33c4.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('72','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-4cacc44e69d863a9b2ec48a3e68a5aaf','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-4cacc44e69d863a9b2ec48a3e68a5aaf.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('73','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-6c03ec7d56348f30a7827f4339a4c8dd','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-6c03ec7d56348f30a7827f4339a4c8dd.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('74','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-28139e65cf4e546f8d5809e766374a76','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-28139e65cf4e546f8d5809e766374a76.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('75','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-934a591e25182017a26f744443373843','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-9.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-9.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-934a591e25182017a26f744443373843.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('76','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-865ddf35b570759a69fbfe1bcab95336','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-865ddf35b570759a69fbfe1bcab95336.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('77','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-a48cffe74f96f867ed337bd9d2fffe47','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-5.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-5.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-a48cffe74f96f867ed337bd9d2fffe47.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('78','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-68394ee168343b861d1e105e9cb5a8a6','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-6.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-6.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-68394ee168343b861d1e105e9cb5a8a6.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('79','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-8b917da888991916cae56a76ec58e728','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-7.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-7.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-8b917da888991916cae56a76ec58e728.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('80','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-08f8e713a810a136fded70fb6bd6ed60','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-8.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-8.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-08f8e713a810a136fded70fb6bd6ed60.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('81','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-5122fb3cfd05c26aa440779c0e9df5ba','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-10.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/skin-10.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-5122fb3cfd05c26aa440779c0e9df5ba.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('82','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-127d3a2ff63de32923dde91a692c7a15','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-127d3a2ff63de32923dde91a692c7a15.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('83','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-44ba1d0ffd8925022a0458b39c93a40f','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-44ba1d0ffd8925022a0458b39c93a40f.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('84','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-7ae1ba6b276fb58a306f666c2d50b17f','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-7ae1ba6b276fb58a306f666c2d50b17f.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('85','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-08337a8b30ef50d3f0c4199ac1360a3c','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/blockquotes\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-08337a8b30ef50d3f0c4199ac1360a3c.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('86','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-ce5cb72fecbc30d4c603c36f26e7e715','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-ce5cb72fecbc30d4c603c36f26e7e715.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('87','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-194f0572649a4bd120aa1906211e11ca','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-194f0572649a4bd120aa1906211e11ca.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('88','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-129daa92869f49a97d1c0d8103061322','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-129daa92869f49a97d1c0d8103061322.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('89','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-987f2213a92512a32621ab8dda17d137','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/contacts\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-987f2213a92512a32621ab8dda17d137.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('90','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-25615fec6c12790e3e1a8b4982ba8bc2','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/cta\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/cta\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-25615fec6c12790e3e1a8b4982ba8bc2.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('91','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c19015a46933cb9c86c8e6770fa2b1c3','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/cta\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/cta\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-c19015a46933cb9c86c8e6770fa2b1c3.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('92','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-321c891e4246fb79e2934cad1bce504a','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-321c891e4246fb79e2934cad1bce504a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('93','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-f17c35fa19a85d6a23d2ac35a54d5e55','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-f17c35fa19a85d6a23d2ac35a54d5e55.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('94','2021-02-09 12:35:18','2021-02-09T12:35:18.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-6494103f3c877e2ca20729738a83bc86','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-6494103f3c877e2ca20729738a83bc86.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('95','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-fd4a7afbf3c863d8a85ddbbf09553e31','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-fd4a7afbf3c863d8a85ddbbf09553e31.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('96','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-6b1dad6f75c30a77842c02433c380cdc','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-5.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-5.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-6b1dad6f75c30a77842c02433c380cdc.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('97','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-58e3c590921f6a9e0ba43ec1d875c5f2','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-6.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-6.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-58e3c590921f6a9e0ba43ec1d875c5f2.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('98','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-9daa512d800634cf696c16f8da91a6e9','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-7.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-7.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-9daa512d800634cf696c16f8da91a6e9.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('99','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-7003d29d4314ea503b2c34031f89bb43','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-8.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-8.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-7003d29d4314ea503b2c34031f89bb43.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('100','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-a17f1d8327d674845914c3cac38fbc8b','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-9.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-9.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-a17f1d8327d674845914c3cac38fbc8b.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('101','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-a9f477180cfbf6f02ae5ca24b8022da9','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-10.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/features\/skin-10.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-a9f477180cfbf6f02ae5ca24b8022da9.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('102','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-e044dfd85bf287aa594bc901208109b9','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/galleries\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/galleries\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-e044dfd85bf287aa594bc901208109b9.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('103','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-3cc6fafab863de8844ec38039557bbc0','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/galleries\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/galleries\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-3cc6fafab863de8844ec38039557bbc0.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('104','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b66096fe7939afda77213d4f8e2433ec','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/galleries\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/galleries\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-b66096fe7939afda77213d4f8e2433ec.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('105','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c5ea57303ceb9b36642a3602457eaa1a','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-banners\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-banners\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-c5ea57303ceb9b36642a3602457eaa1a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('106','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-af1baa2144e788b75e23d61e7f097a92','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-banners\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-banners\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-af1baa2144e788b75e23d61e7f097a92.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('107','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-bd85d199cab9dfc77550b264396014ae','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-banners\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-banners\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-bd85d199cab9dfc77550b264396014ae.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('108','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-eb89cf9e5d2dc12ca29244c8c606f533','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-sliders\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/home-sliders\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-eb89cf9e5d2dc12ca29244c8c606f533.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('109','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-6ab76eaf5ebd9e2a12d48ecf9b36c2c7','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-6ab76eaf5ebd9e2a12d48ecf9b36c2c7.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('110','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-ca63fe019bdcffb5e82bba88b67430c5','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-ca63fe019bdcffb5e82bba88b67430c5.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('111','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-1d91299dc536b3708a38c4a221b85063','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-1d91299dc536b3708a38c4a221b85063.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('112','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-038df23973a42878f07332c6716092ad','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-038df23973a42878f07332c6716092ad.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('113','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-2a945c70efb7c835d05171db1f3ece07','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-5.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-5.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-2a945c70efb7c835d05171db1f3ece07.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('114','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-35e897359915fddde6398d45a2dc0192','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-6.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-6.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-35e897359915fddde6398d45a2dc0192.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('115','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-34bc5c2305f8fb034a8c003fe53fb0d2','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-7.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/info-blocks\/skin-7.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-34bc5c2305f8fb034a8c003fe53fb0d2.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('116','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-28219f38a74aa46a8a7d11ec0503d88c','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/partners\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/partners\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-28219f38a74aa46a8a7d11ec0503d88c.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('117','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-a38d7ba90bf2d5f83f658c9985e7b7b8','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/partners\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/partners\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-a38d7ba90bf2d5f83f658c9985e7b7b8.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('118','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-3e5ff73580ced0b1cce986b4e06c544e','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/people\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/people\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-3e5ff73580ced0b1cce986b4e06c544e.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('119','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-356e6a41e66da70a1f98da9281c9ea4f','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/people\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/people\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-356e6a41e66da70a1f98da9281c9ea4f.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('120','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-0715455bbb168e7a16c28bdbca0db883','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-0715455bbb168e7a16c28bdbca0db883.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('121','2021-02-09 12:35:19','2021-02-09T12:35:19.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b514262d96500046a1bcdc1a372a917b','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-b514262d96500046a1bcdc1a372a917b.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('122','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c1fb473fbd06adc09b4467f12fe1faf7','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-c1fb473fbd06adc09b4467f12fe1faf7.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('123','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-3e034923e4a3e2b2fb646a822a4af6bc','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-3e034923e4a3e2b2fb646a822a4af6bc.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('124','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b6b4392693be381261f050d703ad0135','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-5.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/posts\/skin-5.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-b6b4392693be381261f050d703ad0135.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('125','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-230a24a14ee2f9fbd3f5981d8dc405cd','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/pricing\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/pricing\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-230a24a14ee2f9fbd3f5981d8dc405cd.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('126','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-2af9c30b34e709d7bf9138b8c78e9081','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/products\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/products\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-2af9c30b34e709d7bf9138b8c78e9081.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('127','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-e757548ccb0660b888507ea92afa5ffd','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/products\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/products\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-e757548ccb0660b888507ea92afa5ffd.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('128','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c6781bc8e9b8349470fb4577ef2fb08a','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-1.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-c6781bc8e9b8349470fb4577ef2fb08a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('129','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-e3c75cddc475f4337f13fcd926d53f65','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-2.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-e3c75cddc475f4337f13fcd926d53f65.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('130','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-df4554f2cac02d8d540e84f2b97900a7','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-3.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-df4554f2cac02d8d540e84f2b97900a7.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('131','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-74562c064ad8fe3afdfd040bed79b318','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-4.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-4.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-74562c064ad8fe3afdfd040bed79b318.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('132','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-09929b5ddbe0992d3c78f534267bc429','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-5.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-5.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-09929b5ddbe0992d3c78f534267bc429.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('133','2021-02-09 12:35:20','2021-02-09T12:35:20.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-4c778d5110b21a34056e60198221269b','{"mtime":1611580680,"base_src":"userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-6.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/templates\/new-world\/modules\/layouts\/templates\/videos\/skin-6.jpg","width":340,"height":340,"cache_path_relative":"cache\\thumbnails\\340\\tn-4c778d5110b21a34056e60198221269b.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('134','2021-02-09 12:40:30','2021-02-09T12:40:30.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b6e733b91e578acd75a7610c1c12ec6d','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/bg-section-team.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/bg-section-team.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-b6e733b91e578acd75a7610c1c12ec6d.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('135','2021-02-09 12:40:30','2021-02-09T12:40:30.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-bbfa93134919f9a0ae866230e3b7c79f','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/cruises-result.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/cruises-result.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-bbfa93134919f9a0ae866230e3b7c79f.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('136','2021-02-09 12:40:30','2021-02-09T12:40:30.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-d9fe978f44e6234d9683e7fe898c2fc9','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/blog-detail.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/blog-detail.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-d9fe978f44e6234d9683e7fe898c2fc9.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('137','2021-02-09 12:40:30','2021-02-09T12:40:30.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-600a3a2943b4569b0e81366541b6d0b9','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/blog-image-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/blog-image-1.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-600a3a2943b4569b0e81366541b6d0b9.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('138','2021-02-09 12:40:31','2021-02-09T12:40:31.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b12df517a6f0ba96b8f6874d67cb4384','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/homepage-default-banner.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/homepage-default-banner.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-b12df517a6f0ba96b8f6874d67cb4384.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('139','2021-02-09 12:40:32','2021-02-09T12:40:32.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-df74d23b45179d7ee2e90f59c5b3f3ba','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/website_whmcs_microweber-v2_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/website_whmcs_microweber-v2_1.jpg","width":120,"height":120,"crop":true,"cache_path_relative":"cache\\thumbnails\\120\\tn-df74d23b45179d7ee2e90f59c5b3f3ba.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('140','2021-02-09 12:40:37','2021-02-09T12:40:37.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-499b340e0207cf0be2bc274589844f59','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-499b340e0207cf0be2bc274589844f59.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('141','2021-02-09 12:40:37','2021-02-09T12:40:37.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-44ab870b772b3c632f87d7d53a9c5124','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-44ab870b772b3c632f87d7d53a9c5124.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('142','2021-02-09 12:40:37','2021-02-09T12:40:37.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-7a441c7ce28aa15f80e60a44e47550a3','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/5__85794.1557124344.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/5__85794.1557124344.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-7a441c7ce28aa15f80e60a44e47550a3.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('143','2021-02-09 12:40:37','2021-02-09T12:40:37.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-d89e853b7011f536eae74ae0d026db16','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/14__82429.1557125318.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/14__82429.1557125318.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-d89e853b7011f536eae74ae0d026db16.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('144','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-75e909d4842f4506fc295b7887f01704','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1__43193.1557124343_3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1__43193.1557124343_3.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-75e909d4842f4506fc295b7887f01704.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('145','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-eb2f98724631ae80e398e7ef0aef7def','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-eb2f98724631ae80e398e7ef0aef7def.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('146','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-80faf3244149d3369eedf39a968b3c48','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/4__71728.1557124344.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/4__71728.1557124344.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-80faf3244149d3369eedf39a968b3c48.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('147','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-ad21fadd4618b77b64ac5d87b4b8ec8d','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-ad21fadd4618b77b64ac5d87b4b8ec8d.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('148','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-54df7ec5620ce733a17cfac6374f5bc4','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-54df7ec5620ce733a17cfac6374f5bc4.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('149','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-76099b0c658ab95924de53dfbc8b6dc5','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/5__85794.1557124344.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/5__85794.1557124344.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-76099b0c658ab95924de53dfbc8b6dc5.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('150','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-78962e9f8ec4c8ea38f2834baa54ed74','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/14__82429.1557125318.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/14__82429.1557125318.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-78962e9f8ec4c8ea38f2834baa54ed74.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('151','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-35f5decae9153259ba63fcaca110d8bd','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1__43193.1557124343_3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1__43193.1557124343_3.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-35f5decae9153259ba63fcaca110d8bd.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('152','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-36f230be039de4f10f9b808ab1a7159e','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-36f230be039de4f10f9b808ab1a7159e.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('153','2021-02-09 12:40:38','2021-02-09T12:40:38.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-5f0d8a07de7ffa8cf1c06cda8d9ce785','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/4__71728.1557124344.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/4__71728.1557124344.jpg","width":450,"height":450,"cache_path_relative":"cache\\thumbnails\\450\\tn-5f0d8a07de7ffa8cf1c06cda8d9ce785.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('154','2021-02-09 12:40:49','2021-02-09T12:40:49.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-499b340e0207cf0be2bc274589844f59','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-499b340e0207cf0be2bc274589844f59.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('155','2021-02-09 12:41:14','2021-02-09T12:41:14.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-774601d3ec93a0081cc58c38bf7f3534','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-774601d3ec93a0081cc58c38bf7f3534.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('156','2021-02-09 12:41:14','2021-02-09T12:41:14.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-6e5aa1794c068b462e6d1e2e3f3aa814','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-6e5aa1794c068b462e6d1e2e3f3aa814.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('157','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-8904c26dac55ac3b3db3e3524f058b01','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-8904c26dac55ac3b3db3e3524f058b01.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('158','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-68902a423de182bb874c838461748c2a','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/12__41534.1557125318.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/12__41534.1557125318.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-68902a423de182bb874c838461748c2a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('159','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-4e1c9136d0c52543b969cea477d9caa7','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/12__41534.1557125318.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/12__41534.1557125318.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-4e1c9136d0c52543b969cea477d9caa7.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('160','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-1e159946ccd5275922de546d061ccd4a','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/12__41534.1557125318.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/12__41534.1557125318.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-1e159946ccd5275922de546d061ccd4a.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('161','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b87c2df74a3b2b773a906d47a58368a4','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030_1.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-b87c2df74a3b2b773a906d47a58368a4.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('162','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-65ff0b361a08e0969e58b5386509fe74','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030_1.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-65ff0b361a08e0969e58b5386509fe74.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('163','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-7ccccada08b0a70026e7df58678cce62','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030_1.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-7ccccada08b0a70026e7df58678cce62.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('164','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-08293dd45fd9fb22eb4f83ede725b2ab','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/12__41534.1557125318_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/12__41534.1557125318_1.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-08293dd45fd9fb22eb4f83ede725b2ab.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('165','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b38ce4e2c351b4a0bd73566901dd8062','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/12__41534.1557125318_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/12__41534.1557125318_1.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-b38ce4e2c351b4a0bd73566901dd8062.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('166','2021-02-09 12:41:15','2021-02-09T12:41:15.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-e5080d177a0eef6499b7f61d40790b17','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/12__41534.1557125318_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/12__41534.1557125318_1.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-e5080d177a0eef6499b7f61d40790b17.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('167','2021-02-09 12:45:30','2021-02-09T12:45:30.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-822cad980709a01610f0bd9ff450eaae','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/7__48004.1557125030.jpg","width":70,"height":70,"crop":true,"cache_path_relative":"cache\\thumbnails\\70\\tn-822cad980709a01610f0bd9ff450eaae.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('168','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-91ffe323c84377255075d00b501e4f21','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-91ffe323c84377255075d00b501e4f21.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('169','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-bd5644d4c6b942e2a9af4ffe7e185c09','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-bd5644d4c6b942e2a9af4ffe7e185c09.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('170','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-df87a08739815daab59bffd8283d745d','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-df87a08739815daab59bffd8283d745d.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('171','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-b97325a40931f00724dcbde3ea332940','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/16__95752.1557125556.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/16__95752.1557125556.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-b97325a40931f00724dcbde3ea332940.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('172','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-737c0ba4f04ace23cb9b0a2d7b346785','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/16__95752.1557125556.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/16__95752.1557125556.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-737c0ba4f04ace23cb9b0a2d7b346785.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('173','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c1d689ed88acb72b07ff1fe68b32b438','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/16__95752.1557125556.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/16__95752.1557125556.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-c1d689ed88acb72b07ff1fe68b32b438.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('174','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-af2e3fc1e946bbcc577e7618933d0603','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1__43193.1557124343_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1__43193.1557124343_1.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-af2e3fc1e946bbcc577e7618933d0603.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('175','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-31617bbd8f71412c9f19f61efd82659d','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1__43193.1557124343_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1__43193.1557124343_1.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-31617bbd8f71412c9f19f61efd82659d.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('176','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-baa204dcad4d311234a8b89ce8398500','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/1__43193.1557124343_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/1__43193.1557124343_1.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-baa204dcad4d311234a8b89ce8398500.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('177','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-55c277d0d0c9ab957ede82a892d59fa4','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/16__95752.1557125556_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/16__95752.1557125556_2.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-55c277d0d0c9ab957ede82a892d59fa4.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('178','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-156ecd85a86961cdd2d28b8fa3b120f4','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/16__95752.1557125556_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/16__95752.1557125556_2.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-156ecd85a86961cdd2d28b8fa3b120f4.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('179','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-8ced6e30ad38ab2a365ca7513db494eb','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/16__95752.1557125556_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/16__95752.1557125556_2.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-8ced6e30ad38ab2a365ca7513db494eb.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('180','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-60d07c3d7e2a17dd241cb56b7c8e5e94','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343_2.jpg","width":1920,"height":1920,"cache_path_relative":"cache\\thumbnails\\1920\\tn-60d07c3d7e2a17dd241cb56b7c8e5e94.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('181','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-d29366c8948dcb70b3a7ab0af0bbd03c','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343_2.jpg","width":800,"height":800,"cache_path_relative":"cache\\thumbnails\\800\\tn-d29366c8948dcb70b3a7ab0af0bbd03c.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('182','2021-02-09 13:12:41','2021-02-09T13:12:41.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-aaa0df3d0098929fcd4bf01d939c7b78','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343_2.jpg","width":200,"height":200,"cache_path_relative":"cache\\thumbnails\\200\\tn-aaa0df3d0098929fcd4bf01d939c7b78.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('183','2021-02-09 13:14:43','2021-02-09T13:14:43.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-c61db3c3f96657c44d4357f59637196f','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/bg-section-team.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/bg-section-team.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-c61db3c3f96657c44d4357f59637196f.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('184','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-626cc5275092b6e59a5d8c798a444a42','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/cruises-result.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/cruises-result.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-626cc5275092b6e59a5d8c798a444a42.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('185','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-414cdca73298bd1aab3f762bbb32be93','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/blog-detail.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/blog-detail.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-414cdca73298bd1aab3f762bbb32be93.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('186','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-2296272274cb2f3ddff5d558a003969b','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/blog-image-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/blog-image-1.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-2296272274cb2f3ddff5d558a003969b.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('187','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-73fc6538312606f5da9442fdc9d058a9','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/homepage-default-banner.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/homepage-default-banner.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-73fc6538312606f5da9442fdc9d058a9.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('188','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-8ab4ddf784d31bad25cde75003afe2a6','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/bg-section-team.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/bg-section-team.jpg","width":535,"height":285,"crop":true,"cache_path_relative":"cache\\thumbnails\\535\\tn-8ab4ddf784d31bad25cde75003afe2a6.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('189','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-24a4b413e4863b0807206216e1ab0cbe','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/cruises-result.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/cruises-result.jpg","width":535,"height":285,"crop":true,"cache_path_relative":"cache\\thumbnails\\535\\tn-24a4b413e4863b0807206216e1ab0cbe.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('190','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-9901909d0c25c2c8a0890e306e7acd10','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/blog-detail.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/blog-detail.jpg","width":535,"height":285,"crop":true,"cache_path_relative":"cache\\thumbnails\\535\\tn-9901909d0c25c2c8a0890e306e7acd10.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('191','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-95c8d149ef3cdc4f16616cae522e0577','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/blog-image-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/blog-image-1.jpg","width":535,"height":285,"crop":true,"cache_path_relative":"cache\\thumbnails\\535\\tn-95c8d149ef3cdc4f16616cae522e0577.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('192','2021-02-09 13:14:44','2021-02-09T13:14:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-632c2fd242587249248f66e732b2190c','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/homepage-default-banner.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/homepage-default-banner.jpg","width":535,"height":285,"crop":true,"cache_path_relative":"cache\\thumbnails\\535\\tn-632c2fd242587249248f66e732b2190c.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('193','2021-02-09 13:14:48','2021-02-09T13:14:48.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-d4077cb3e3ca4447179532516b049a54','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/slide-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/slide-1.jpg","width":1920,"height":760,"cache_path_relative":"cache\\thumbnails\\1920\\tn-d4077cb3e3ca4447179532516b049a54.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('194','2021-02-09 13:14:48','2021-02-09T13:14:48.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-d516be79439c799fd666cccd73b59e60','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/slide-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/slide-2.jpg","width":1920,"height":760,"cache_path_relative":"cache\\thumbnails\\1920\\tn-d516be79439c799fd666cccd73b59e60.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('195','2021-02-09 13:14:49','2021-02-09T13:14:49.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-ac260210953243eb63aa2534aa920232','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/img-7.png","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/img-7.png","width":1440,"height":656,"cache_path_relative":"cache\\thumbnails\\1440\\tn-ac260210953243eb63aa2534aa920232.png"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('196','2021-02-09 13:14:49','2021-02-09T13:14:49.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-f79e4cd306d8924daf69d31f3d05fceb','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/lsJ9jHKIqHg-1600.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/lsJ9jHKIqHg-1600.jpg","width":1440,"height":656,"cache_path_relative":"cache\\thumbnails\\1440\\tn-f79e4cd306d8924daf69d31f3d05fceb.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('197','2021-02-09 13:14:49','2021-02-09T13:14:49.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-606bc00abc357df992aa27a3166cdc0b','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/L4-16dmZ-1c-1600.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/L4-16dmZ-1c-1600.jpg","width":1440,"height":656,"cache_path_relative":"cache\\thumbnails\\1440\\tn-606bc00abc357df992aa27a3166cdc0b.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('198','2021-02-09 13:14:49','2021-02-09T13:14:49.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-797002bcd34f8e342f0ed984ab98cf4b','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/testimonial.png","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/testimonial.png","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-797002bcd34f8e342f0ed984ab98cf4b.png"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('199','2021-02-09 13:14:49','2021-02-09T13:14:49.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-a9805b5d5b47f33107ed50bde1408d24','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/athenathemes-tribe-10.png","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/athenathemes-tribe-10.png","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-a9805b5d5b47f33107ed50bde1408d24.png"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('200','2021-02-09 13:14:50','2021-02-09T13:14:50.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-4e00ac433f67563c3a3816df57b237b4','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/feature-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/feature-1.jpg","width":640,"height":640,"cache_path_relative":"cache\\thumbnails\\640\\tn-4e00ac433f67563c3a3816df57b237b4.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('201','2021-02-09 13:14:50','2021-02-09T13:14:50.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-06c27bf962fdd2ac56ffe52335353028','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/feature-2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/feature-2.jpg","width":640,"height":640,"cache_path_relative":"cache\\thumbnails\\640\\tn-06c27bf962fdd2ac56ffe52335353028.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('202','2021-02-09 13:14:50','2021-02-09T13:14:50.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-fc52e85e718e55821d29c8bcfddabcd0','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/feature-3.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/feature-3.jpg","width":640,"height":640,"cache_path_relative":"cache\\thumbnails\\640\\tn-fc52e85e718e55821d29c8bcfddabcd0.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('203','2021-02-09 13:14:50','2021-02-09T13:14:50.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-9caba782bc27b3903e1a16b81d3fd718','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/website_whmcs_microweber-v2_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/website_whmcs_microweber-v2_1.jpg","width":350,"height":350,"cache_path_relative":"cache\\thumbnails\\350\\tn-9caba782bc27b3903e1a16b81d3fd718.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('204','2021-02-10 12:13:40','2021-02-10T12:13:40.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-2c9f1b8348280b6da7604645bc417ecb','{"mtime":1612873846,"base_src":"userfiles\/media\/templates.microweber.com\/website_whmcs_microweber-v2_1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/website_whmcs_microweber-v2_1.jpg","width":535,"height":285,"crop":true,"cache_path_relative":"cache\\thumbnails\\535\\tn-2c9f1b8348280b6da7604645bc417ecb.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('205','2021-02-10 12:45:44','2021-02-10T12:45:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-3b873bdb1fed725cfa8ea0c02bf7d158','{"mtime":1611568884,"base_src":"userfiles\/modules\/microweber\/api\/libs\/mw-ui\/assets\/img\/no-user.png","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/modules\/microweber\/api\/libs\/mw-ui\/assets\/img\/no-user.png","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-3b873bdb1fed725cfa8ea0c02bf7d158.png"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('206','2021-02-10 13:24:27','2021-02-10T13:24:27.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-fc415d480a76a15b1a9ab40342b77c12','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/cruises-result.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/cruises-result.jpg","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-fc415d480a76a15b1a9ab40342b77c12.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('207','2021-02-10 13:24:27','2021-02-10T13:24:27.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-acccbcf0f8bd9daf1ddfc25cac86dd85','{"mtime":1612961662,"base_src":"userfiles\/media\/127.0.0.5\/microweber-logo.png","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/127.0.0.5\/microweber-logo.png","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-acccbcf0f8bd9daf1ddfc25cac86dd85.png"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('208','2021-02-10 13:29:40','2021-02-10T13:29:40.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-9b1d88f746e6e113a2f216fecf06f1db','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":70,"height":70,"crop":true,"cache_path_relative":"cache\\thumbnails\\70\\tn-9b1d88f746e6e113a2f216fecf06f1db.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('209','2021-02-10 13:29:50','2021-02-10T13:29:50.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-5943286d658f81fdcbb2ad710bbdd754','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","width":70,"height":70,"crop":true,"cache_path_relative":"cache\\thumbnails\\70\\tn-5943286d658f81fdcbb2ad710bbdd754.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('210','2021-02-10 13:29:50','2021-02-10T13:29:50.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-5943286d658f81fdcbb2ad710bbdd754','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","width":70,"height":70,"crop":true,"cache_path_relative":"cache\\thumbnails\\70\\tn-5943286d658f81fdcbb2ad710bbdd754.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('211','2021-02-10 13:32:10','2021-02-10T13:32:10.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-cd3ada9817509b994f5938673ff0ace3','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/2__69884.1557124343.jpg","width":160,"height":160,"cache_path_relative":"cache\\thumbnails\\160\\tn-cd3ada9817509b994f5938673ff0ace3.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('212','2021-02-10 13:32:22','2021-02-10T13:32:22.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-69aa3ca0635fe43b44ccd566e23ce8d7','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/13__85251.1557125318_2.jpg","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-69aa3ca0635fe43b44ccd566e23ce8d7.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('213','2021-02-10 14:08:23','2021-02-10T14:08:23.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-37dbdb79465c68055652c7fcbf5c0718','{"mtime":1611568883,"base_src":"userfiles\/modules\/comments\/\/img\/comment-default-1.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/modules\/comments\/\/img\/comment-default-1.jpg","width":60,"height":60,"cache_path_relative":"cache\\thumbnails\\60\\tn-37dbdb79465c68055652c7fcbf5c0718.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('214','2021-02-10 14:08:44','2021-02-10T14:08:44.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-edc80ad7dd7525a61d4a44095ef83855','{"mtime":1612873845,"base_src":"userfiles\/media\/templates.microweber.com\/cruises-result.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/templates.microweber.com\/cruises-result.jpg","width":200,"height":200,"crop":true,"cache_path_relative":"cache\\thumbnails\\200\\tn-edc80ad7dd7525a61d4a44095ef83855.jpg"}'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename,image_options) VALUES('215','2021-02-10 14:41:34','2021-02-10T14:41:34.000000Z','','','vjhFOkbEThH4j2FlO63Z51J7AfbXH8wncLddA6NQ','media_tn_temp','','media_tn_temp','','','','','tn-9f127e0044fa463d250ae784730348f6','{"mtime":1612967959,"base_src":"userfiles\/media\/127.0.0.5\/greg-rakozy-ompaz-dn-9i-unsplash.jpg","src":"http:\/\/127.0.0.5\/mw_eFunc\/microweber\/userfiles\/media\/127.0.0.5\/greg-rakozy-ompaz-dn-9i-unsplash.jpg","width":120,"height":120,"cache_path_relative":"cache\\thumbnails\\120\\tn-9f127e0044fa463d250ae784730348f6.jpg"}'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('1','module','cart-checkout-shop-shipping-shop-shipping-gateways-country','0','address','Address','address','','','2020-01-22 14:10:07','2020-01-22 14:10:07','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"address","field_size":12}','1','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('2','module','module-layouts-8--3-contact-form','0','text','Your Name','your-name','Your Name','','2020-01-22 14:10:07','2020-01-22 14:10:07','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('3','module','module-layouts-8--3-contact-form','1','email','E-mail Address','e-mail-address','E-mail Address','','2020-01-22 14:10:07','2020-01-22 14:10:07','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"email","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('4','module','module-layouts-8--3-contact-form','2','phone','Phone','phone','Phone','','2020-01-22 14:10:07','2020-01-22 14:10:07','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"phone","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('5','module','module-layouts-8--3-contact-form','3','text','Company','company','Company','','2020-01-22 14:10:07','2020-01-22 14:10:07','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('6','module','module-layouts-8--3-contact-form','4','text','Message','message','Message','','2020-01-22 14:10:07','2020-01-22 14:10:07','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"text","field_size":"12","as_text_area":true}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('7','module','module-layouts-5--3-contact-form','0','text','Your Name','your-name','Your Name','','2020-01-22 14:10:13','2020-01-22 14:10:13','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('8','module','module-layouts-5--3-contact-form','1','email','E-mail Address','e-mail-address','E-mail Address','','2020-01-22 14:10:13','2020-01-22 14:10:13','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"email","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('9','module','module-layouts-5--3-contact-form','2','phone','Phone','phone','Phone','','2020-01-22 14:10:13','2020-01-22 14:10:13','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"phone","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('10','module','module-layouts-5--3-contact-form','3','text','Company','company','Company','','2020-01-22 14:10:13','2020-01-22 14:10:13','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('11','module','module-layouts-5--3-contact-form','4','text','Message','message','Message','','2020-01-22 14:10:13','2020-01-22 14:10:13','1','1','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','{"field_type":"text","field_size":"12","as_text_area":true}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('12','module','module-layouts-14--8-contact-form','0','text','Your Name','your-name','Your Name','','2020-01-27 10:49:31','2020-01-27 10:49:31','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('13','module','module-layouts-14--8-contact-form','1','email','E-mail Address','e-mail-address','E-mail Address','','2020-01-27 10:49:31','2020-01-27 10:49:31','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"email","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('14','module','module-layouts-14--8-contact-form','2','phone','Phone','phone','Phone','','2020-01-27 10:49:31','2020-01-27 10:49:31','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"phone","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('15','module','module-layouts-14--8-contact-form','3','text','Company','company','Company','','2020-01-27 10:49:31','2020-01-27 10:49:31','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('16','module','module-layouts-14--8-contact-form','4','text','Message','message','Message','','2020-01-27 10:49:31','2020-01-27 10:49:31','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"text","field_size":"12","as_text_area":true}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('17','module','module-layouts-6--8-contact-form','0','text','Your Name','your-name','Your Name','','2020-01-27 10:49:34','2020-01-27 10:49:34','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"text","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('18','module','module-layouts-6--8-contact-form','1','email','E-mail Address','e-mail-address','E-mail Address','','2020-01-27 10:49:34','2020-01-27 10:49:34','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"email","field_size":"6"}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('21','module','module-layouts-6--8-contact-form','4','text','Message','message','Message','','2020-01-27 10:49:34','2020-01-27 10:49:34','1','1','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','{"field_type":"text","field_size":"12","as_text_area":true}','0','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('22','content','9','','price','price','price','','','2020-02-04 13:53:10','2020-02-04 13:52:32','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('23','content','10','','price','price','price','','','2020-02-04 13:54:16','2020-02-04 13:53:55','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('24','content','11','','price','price','price','','','2020-02-04 13:55:22','2020-02-04 13:54:57','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('25','content','12','','price','price','price','','','2020-02-04 13:58:24','2020-02-04 13:57:19','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('26','content','13','','price','price','price','','','2020-02-04 13:58:54','2020-02-04 13:58:30','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('27','content','14','','price','price','price','','','2020-02-04 14:00:10','2020-02-04 13:59:23','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('28','content','15','','price','price','price','','','2020-02-04 14:01:02','2020-02-04 14:00:25','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,placeholder,error_text,updated_at,created_at,created_by,edited_by,session_id,options,show_label,is_active,required,copy_of_field) VALUES('29','content','19','','price','price','price','','','2020-02-04 16:16:57','2020-02-04 16:16:57','1','1','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','1','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','2','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('3','3','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('4','4','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('5','5','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('6','6','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('7','7','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('8','8','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('9','9','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('10','10','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('11','11','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('12','12','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('13','13','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('14','14','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('15','15','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('16','16','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('17','17','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('18','18','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('21','21','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('22','22','30.99','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('23','23','59.85','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('24','24','305.99','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('25','25','199.95','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('26','26','223.99','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('27','27','97.99','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('28','28','19.00','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('29','29','0','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('1','header_menu','menu','','','','','2020-01-21 10:14:04','2020-01-21 10:14:04','1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('2','','menu_item','1','1','','0','2020-01-21 10:14:04','2020-01-21 10:14:04','1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('3','footer_menu','menu','','','','','2020-01-21 10:14:04','2020-01-21 10:14:04','1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('5','top_menu_1','menu','','','','','2020-01-21 10:14:14','2020-01-21 10:14:14','1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('6','top_menu_2','menu','','','','','2020-01-21 10:23:10','2020-01-21 10:23:10','1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('7','footer_menu_1','menu','','','','','2020-01-21 10:30:08','2020-01-21 10:30:08','1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('8','Contact Us','menu_item','1','','','5','2020-01-27 10:41:26','2020-01-27 10:41:26','','','','{SITE_URL}contact-us','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('9','Home','menu_item','7','','','0','2020-01-27 11:31:46','2020-01-27 11:31:46','','','','{SITE_URL}','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('10','About us','menu_item','1','','','3','2020-01-27 11:43:04','2020-01-27 11:43:04','','','','{SITE_URL}about-us','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('11','About us','menu_item','7','','','3','2020-01-27 11:43:20','2020-01-27 11:43:20','','','','{SITE_URL}about-us','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('12','Contact Us','menu_item','7','','','5','2020-01-27 11:43:24','2020-01-27 11:43:24','','','','{SITE_URL}contact-us','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('13','Services','menu_item','1','','','4','2020-01-30 09:47:59','2020-01-30 09:47:59','','','','{SITE_URL}services','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('14','Services','menu_item','7','','','4','2020-01-30 09:48:13','2020-01-30 09:48:13','','','','{SITE_URL}services','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('15','Shop','menu_item','1','','','2','2020-02-04 14:01:21','2020-02-04 14:01:21','','','','{SITE_URL}shop','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('16','Shop','menu_item','7','','','2','2020-02-04 14:01:41','2020-02-04 14:01:41','','','','{SITE_URL}shop','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('17','Blog','menu_item','1','','','1','2020-02-04 14:13:59','2020-02-04 14:13:59','','','','{SITE_URL}blog','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url,url_target,size,default_image,rollover_image) VALUES('18','Blog','menu_item','7','','','1','2020-02-04 14:14:28','2020-02-04 14:14:28','','','','{SITE_URL}blog','','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('1','2020-02-04 13:50:41','2020-02-04T13:50:41.000000Z','1','1','category','Accessoaries','accessoaries','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('2','2020-02-04 13:50:58','2020-02-04T13:50:58.000000Z','1','1','category','Clothes','clothes','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('3','2020-02-04 13:51:05','2020-02-04T13:51:05.000000Z','1','1','category','Decor','decor','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('4','2020-02-04 13:51:14','2020-02-04T13:51:14.000000Z','1','1','category','Hoodies','hoodies','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('5','2020-02-04 13:51:42','2020-02-04T13:51:42.000000Z','1','1','category','Sound Systems','sound-systems','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('6','2020-02-04 13:51:53','2020-02-04T13:51:53.000000Z','1','1','category','T-shirts','t-shirts','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories (id,updated_at,created_at,created_by,edited_by,data_type,title,url,parent_id,description,content,rel_type,rel_id,position,is_deleted,is_hidden,users_can_create_subcategories,users_can_create_content,users_can_create_content_allowed_usergroups,category_meta_title,category_meta_keywords,category_meta_description,category_subtype,category_subtype_settings) VALUES('7','2020-02-04 13:52:04','2020-02-04T13:52:04.000000Z','1','1','category','Others','others','0','','','content','8','0','0','0','','0','','','','','default',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('1','1','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('2','7','content','9'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('3','5','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('4','7','content','10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('5','7','content','11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('6','5','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('7','7','content','12'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('8','5','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('9','7','content','13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('10','5','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('11','7','content','14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('12','1','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('13','7','content','15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('14','1','content','16'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items (id,parent_id,rel_type,rel_id) VALUES('15','7','content','16'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */forms_data (id,created_at,created_by,rel_type,rel_id,list_id,form_values,module_name,url,user_ip) VALUES('2','2021-02-10 14:48:18','','module','module-layouts-5--3-contact-form','0','{"Your_Name":"John Doe","E-mail_Address":"john@testmail.com","Phone":"123456789","Company":"John&rsquo;s company","Message":"I like your website and services, please contact me when you can.\nThis is my test message from the contact us form."}','contact_form','','127.0.0.1'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('1','2020-01-21 10:14:04','2020-01-21 10:14:04','current_template','new-world','','','','template','','','','','','1',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('2','2021-03-05 09:56:28','2020-01-21 10:14:04','language','en_US','','','','website','','','','','','1',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('3','2020-01-21 10:14:04','2020-01-21 10:14:04','website_title','Microweber','','','','website','','','','','','1',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('4','2021-02-09 12:30:56','','enable_comments','y','','','','comments','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('5','2021-02-09 12:30:56','','shipping_gw_shop/shipping/gateways/country','y','','','','shipping','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('6','2021-02-10 11:37:22','','payment_gw_shop/payments/gateways/paypal','','','','','payments','','','','','shop/payments','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('7','2021-02-09 12:30:56','','currency','USD','','','','payments','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('8','2020-01-27 11:48:04','2020-01-21 10:14:39','size','auto','','','','header-logo','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('9','2020-01-21 10:14:39','2020-01-21 10:14:39','logoimage','{SITE_URL}userfiles/media/templates.microweber.com/logo.png','','','','header-logo','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('10','2020-01-27 11:48:49','2020-01-21 10:21:22','settings','[{"images":"{SITE_URL}userfiles/media/templates.microweber.com/slide-1.jpg","primaryText":"This is the default<br />template of Microweber","secondaryText":"Drag and drop open-source website builder and <br />CMS of new generation.","seemoreText":"Read More","url":"","urlText":"","skin":"left","icon":""},{"images":"{SITE_URL}userfiles/media/templates.microweber.com/slide-2.jpg","primaryText":"This is the default<br />template of Microweber","secondaryText":"Drag and drop open-source website builder and <br />CMS of new generation.","seemoreText":"Read More","url":"","urlText":"","skin":"right","icon":""}]','','','','module-layouts-1-slider','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('11','2020-01-21 10:29:46','2020-01-21 10:24:54','settings','[{"images":"{SITE_URL}userfiles/media/templates.microweber.com/img-7.png","primaryText":"","secondaryText":"","seemoreText":"","url":"","urlText":"","skin":"default","icon":"<span class=\"mw-icon mw-micon- mw-micon-Car-3\"></span>"},{"images":"{SITE_URL}userfiles/media/templates.microweber.com/lsJ9jHKIqHg-1600.jpg","primaryText":"","secondaryText":"","seemoreText":"","url":"","urlText":"","skin":"default","icon":"<span class=\"mw-icon mw-micon- mw-micon-Battery-100\"></span>"},{"images":"{SITE_URL}userfiles/media/templates.microweber.com/L4-16dmZ-1c-1600.jpg","primaryText":"","secondaryText":"","seemoreText":"","url":"","urlText":"","skin":"default","icon":"<span class=\"mw-icon mw-micon- mw-micon-Idea-5\"></span>"}]','','','','module-layouts-1--14-slider','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('12','2020-01-21 14:08:44','2020-01-21 14:08:44','controls','true','','','','module-layouts-1-slider','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('13','2020-01-21 14:33:23','2020-01-21 14:29:03','settings','[{"images":"{SITE_URL}userfiles/media/templates.microweber.com/feature-1.jpg","primaryText":"My Slider","secondaryText":"Microweber is one of the best website builders and CMS in the world. Use it for your own project, website or online store, for free!","seemoreText":"See more","url":"","urlText":"","skin":"default","icon":"<span class=\"mw-icon mw-micon- mw-micon-Like-2\"></span>"},{"images":"{SITE_URL}userfiles/media/templates.microweber.com/feature-2.jpg","primaryText":"It Is Free","secondaryText":"Microweber is one of the best website builders and CMS in the world. Use it for your own project, website or online store, for free!","seemoreText":"See more","url":"","urlText":"","skin":"default","icon":"<span class=\"mw-icon mw-micon- mw-micon-Hand\"></span>"},{"images":"{SITE_URL}userfiles/media/templates.microweber.com/feature-3.jpg","primaryText":"It Is Powerful","secondaryText":"Microweber is one of the best website builders and CMS in the world. Use it for your own project, website or online store, for free!","seemoreText":"See more","url":"","urlText":"","skin":"default","icon":"<span class=\"mw-icon mw-micon- mw-micon-Bodybuilding\"></span>"}]','','','','module-layouts-1--21-slider','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('14','2020-01-21 14:34:57','2020-01-21 14:34:57','facebook_enabled','y','','','','footer_socials','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('15','2020-01-21 14:34:58','2020-01-21 14:34:58','twitter_enabled','y','','','','footer_socials','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('16','2020-01-21 14:34:59','2020-01-21 14:34:59','youtube_enabled','y','','','','footer_socials','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('17','2020-01-22 14:10:07','2020-01-22 14:10:07','fields_make_default4115320604','1','','','','make_default_custom_fields','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('18','2020-01-22 14:10:07','2020-01-22 14:10:07','fields_make_default219634127','1','','','','make_default_custom_fields','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('19','2020-01-22 14:10:13','2020-01-22 14:10:13','fields_make_default4163937061','1','','','','make_default_custom_fields','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('20','2020-01-22 14:10:24','2020-01-22 14:10:24','facebook_enabled','y','','','','module-layouts-5--1-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('21','2020-01-22 14:10:24','2020-01-22 14:10:24','twitter_enabled','y','','','','module-layouts-5--1-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('22','2020-01-22 14:10:26','2020-01-22 14:10:26','youtube_enabled','y','','','','module-layouts-5--1-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('23','2020-01-27 10:49:31','2020-01-27 10:49:31','fields_make_default1599011735','1','','','','make_default_custom_fields','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('24','2020-01-27 10:49:34','2020-01-27 10:49:34','fields_make_default1099213446','1','','','','make_default_custom_fields','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('25','2020-01-27 10:59:00','2020-01-27 10:59:00','facebook_enabled','y','','','','module-layouts-6--5-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('26','2020-01-27 10:59:00','2020-01-27 10:59:00','twitter_enabled','y','','','','module-layouts-6--5-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('27','2020-01-27 10:59:01','2020-01-27 10:59:01','pinterest_enabled','y','','','','module-layouts-6--5-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('28','2020-01-27 10:59:05','2020-01-27 10:59:05','youtube_enabled','y','','','','module-layouts-6--5-social-links--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('29','2020-01-27 10:59:06','2020-01-27 10:59:06','linkedin_enabled','y','','','','module-layouts-6--5-social-links--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('30','2020-01-27 10:59:07','2020-01-27 10:59:07','github_enabled','y','','','','module-layouts-6--5-social-links--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('31','2020-01-27 10:59:11','2020-01-27 10:59:11','instagram_enabled','y','','','','module-layouts-6--5-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('32','2020-01-27 10:59:12','2020-01-27 10:59:12','soundcloud_enabled','y','','','','module-layouts-6--5-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('33','2020-01-27 10:59:12','2020-01-27 10:59:12','mixcloud_enabled','y','','','','module-layouts-6--5-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('34','2020-01-27 10:59:19','2020-01-27 10:59:19','medium_enabled','y','','','','module-layouts-6--5-social-links--5','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('35','2020-01-27 10:59:19','2020-01-27 10:59:19','soundcloud_enabled','y','','','','module-layouts-6--5-social-links--5','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('36','2020-01-27 10:59:20','2020-01-27 10:59:20','instagram_enabled','y','','','','module-layouts-6--5-social-links--5','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('37','2020-01-27 10:59:28','2020-01-27 10:59:28','linkedin_enabled','y','','','','module-layouts-6--5-social-links--4','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('38','2020-01-27 10:59:28','2020-01-27 10:59:28','instagram_enabled','y','','','','module-layouts-6--5-social-links--4','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('39','2020-01-27 10:59:30','2020-01-27 10:59:30','facebook_enabled','y','','','','module-layouts-6--5-social-links--4','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('40','2020-01-27 10:59:35','2020-01-27 10:59:35','googleplus_enabled','y','','','','module-layouts-6--5-social-links--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('41','2020-01-27 10:59:35','2020-01-27 10:59:35','pinterest_enabled','y','','','','module-layouts-6--5-social-links--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('42','2020-01-27 10:59:36','2020-01-27 10:59:36','twitter_enabled','y','','','','module-layouts-6--5-social-links--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('43','2020-01-27 11:02:49','2020-01-27 10:59:53','settings','{"0":{"name":"Johny Doe","role":"Marketing","bio":"SEO and Marketing","file":"{SITE_URL}userfiles/media/templates.microweber.com/people-1.jpg","id":"1580122785715"},"1":{"name":"John Doe","role":"Developers","bio":"Back-End Developer","file":"{SITE_URL}userfiles/media/templates.microweber.com/people-2.jpg","id":"1580122785713"},"2":{"name":"Jinna Doe","role":"Designers","bio":"UI/UX Designer","file":"{SITE_URL}userfiles/media/templates.microweber.com/people-4.jpg","id":"1580122785711"},"3":{"name":"Fari Ismail","role":"Designers","bio":"Interface designer","file":"{SITE_URL}userfiles/media/templates.microweber.com/people-3_1.jpg","id":"module-layouts-6--6-teamcard5e2ec2a135fb5"}}','','','','module-layouts-6--6-teamcard','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('44','2020-01-27 11:04:02','2020-01-27 11:04:02','facebook_enabled','y','','','','module-layouts-6--6-teamcard-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('45','2020-01-27 11:04:03','2020-01-27 11:04:03','twitter_enabled','y','','','','module-layouts-6--6-teamcard-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('46','2020-01-27 11:04:03','2020-01-27 11:04:03','pinterest_enabled','y','','','','module-layouts-6--6-teamcard-social-links','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('47','2020-01-27 11:04:08','2020-01-27 11:04:08','youtube_enabled','y','','','','module-layouts-6--6-teamcard-social-links--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('48','2020-01-27 11:04:08','2020-01-27 11:04:08','linkedin_enabled','y','','','','module-layouts-6--6-teamcard-social-links--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('49','2020-01-27 11:07:03','2020-01-27 11:04:09','github_enabled','y','','','','module-layouts-6--6-teamcard-social-links--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('50','2020-01-27 11:04:14','2020-01-27 11:04:14','github_enabled','y','','','','module-layouts-6--6-teamcard-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('51','2020-01-27 11:04:14','2020-01-27 11:04:14','instagram_enabled','y','','','','module-layouts-6--6-teamcard-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('52','2020-01-27 11:04:16','2020-01-27 11:04:16','facebook_enabled','y','','','','module-layouts-6--6-teamcard-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('53','2020-01-27 11:04:21','2020-01-27 11:04:21','facebook_enabled','y','','','','module-layouts-6--6-teamcard-social-links--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('54','2020-01-27 11:04:21','2020-01-27 11:04:21','twitter_enabled','y','','','','module-layouts-6--6-teamcard-social-links--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('55','2020-01-27 11:04:22','2020-01-27 11:04:22','linkedin_enabled','y','','','','module-layouts-6--6-teamcard-social-links--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('56','2020-01-27 11:06:40','2020-01-27 11:06:40','linkedin_enabled','y','','','','module-layouts-6--6-teamcard-social-links--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('57','2020-01-27 11:14:03','2020-01-27 11:14:03','show_testimonials_per_project','Opinions','','','','module-layouts-6--7-testimonials','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('58','2020-01-27 11:14:29','2020-01-27 11:14:29','show_testimonials_per_project','Testimonials','','','','module-layouts-1--18-testimonials','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('59','2020-01-27 11:21:26','2020-01-27 11:21:18','padding-top','8','','','','module-layouts-6--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('60','2020-01-27 11:21:33','2020-01-27 11:21:33','padding-bottom','8','','','','module-layouts-6--1','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('61','2020-01-27 11:28:02','2020-01-27 11:28:02','padding-top','none','','','','layouts-20200127112745','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('62','2020-01-27 11:28:11','2020-01-27 11:28:11','padding-bottom','2','','','','module-layouts-6--5','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('63','2020-01-27 11:28:48','2020-01-27 11:28:48','data-template','bootstrap.php','','','','btn-20200127112839','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('64','2020-01-27 11:28:56','2020-01-27 11:28:56','button_style','btn-primary','','','','btn-20200127112839','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('65','2020-01-27 11:29:05','2020-01-27 11:29:04','text','See Our Portfolio','','','','btn-20200127112839','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('66','2020-01-27 11:29:09','2020-01-27 11:29:09','button_size','btn-default-medium btn-md','','','','btn-20200127112839','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('67','2020-01-27 11:34:44','2020-01-27 11:34:41','padding-top','7','','','','module-layouts-6--8','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('68','2020-01-27 11:34:45','2020-01-27 11:34:45','padding-bottom','7','','','','module-layouts-6--8','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('69','2020-01-27 11:40:03','2020-01-27 11:40:03','padding-bottom','10','','','','module-layouts-6--6','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('70','2020-01-27 11:40:44','2020-01-27 11:40:44','prior','1','','','','module-layouts-6--4-video','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('71','2020-01-27 11:40:44','2020-01-27 11:40:44','embed_url','https://vimeo.com/98679934','','','','module-layouts-6--4-video','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('72','2020-01-27 11:48:04','2020-01-27 11:48:04','logoimage_inverse','{SITE_URL}userfiles/media/templates.microweber.com/logo-dark.png','','','','header-logo','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('73','2020-01-27 11:50:31','2020-01-27 11:50:31','text','Learn More','','','','module-layouts-1--5-btn','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('74','2020-01-27 11:51:15','2020-01-27 11:51:15','prior','1','','','','module-layouts-1--5-video','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('75','2020-01-27 11:51:15','2020-01-27 11:51:15','embed_url','https://vimeo.com/22439234','','','','module-layouts-1--5-video','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('76','2020-01-27 11:52:05','2020-01-27 11:52:00','search_string','microweber','','','','module-layouts-1--24-twitter-feed','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('77','2020-01-27 11:52:08','2020-01-27 11:52:08','number_of_items','1','','','','module-layouts-1--24-twitter-feed','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('78','2020-01-30 09:54:15','2020-01-30 09:54:15','padding-top','10','','','','module-layouts-7--4','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('79','2020-01-30 09:54:27','2020-01-30 09:54:17','padding-bottom','20','','','','module-layouts-7--4','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('80','2020-01-30 09:54:59','2020-01-30 09:54:59','padding-bottom','15','','','','module-layouts-7--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('81','2020-01-30 09:56:16','2020-01-30 09:56:16','padding-bottom','10','','','','module-layouts-5--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('82','2020-01-30 09:56:28','2020-01-30 09:56:19','padding-top','7','','','','module-layouts-5--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('83','2020-01-30 09:57:41','2020-01-30 09:57:23','padding-top','','','','','module-layouts-6--2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('84','2020-01-30 09:57:52','2020-01-30 09:57:52','padding-top','5','','','','module-layouts-6--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('85','2020-01-30 09:59:00','2020-01-30 09:58:56','padding-top','3','','','','module-layouts-1--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('86','2020-01-30 09:59:10','2020-01-30 09:59:03','padding-bottom','10','','','','module-layouts-1--3','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('87','2020-01-30 09:59:48','2020-01-30 09:59:32','padding-top','10','','','','module-layouts-1--8','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('88','2020-01-30 10:00:01','2020-01-30 10:00:01','padding-bottom','10','','','','module-layouts-1--8','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('89','2020-01-30 10:01:13','2020-01-30 10:01:09','padding-top','10','','','','module-layouts-1--17','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('90','2020-01-30 10:01:20','2020-01-30 10:01:16','padding-bottom','2','','','','module-layouts-1--17','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('91','2020-01-30 10:02:13','2020-01-30 10:02:10','padding-bottom','3','','','','module-layouts-1--20','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('92','2020-01-30 10:02:52','2020-01-30 10:02:52','padding-bottom','none','','','','module-layouts-1--22','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('93','2020-01-30 10:03:02','2020-01-30 10:02:59','padding-top','2','','','','module-layouts-1--23','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('94','2020-01-30 10:03:18','2020-01-30 10:03:18','padding-bottom','10','','','','module-layouts-1--24','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('95','2020-02-04 14:11:28','2020-02-04 14:11:25','data-limit','4','','','','module-shop-products-13','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('96','2020-02-04 16:23:29','2020-02-04 16:23:24','data-page-id','22','','','','module-layouts-1--24-posts','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('97','2020-02-17 08:48:07','2020-02-17 08:48:07','padding-bottom','none','','','','module-layouts-2','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('98','2020-02-17 08:48:24','2020-02-17 08:48:22','data-limit','6','','','','module-layouts-2--1-posts','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('99','2020-02-17 08:48:33','2020-02-17 08:48:33','data-page-id','2','','','','module-layouts-2--1-posts','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('100','2020-02-17 09:26:57','2020-02-17 09:26:57','facebook_enabled','y','','','','post-bottom-sharer','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('101','2020-02-17 09:26:58','2020-02-17 09:26:58','twitter_enabled','y','','','','post-bottom-sharer','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('102','2020-02-17 09:54:48','2020-02-17 09:54:48','facebook_enabled','y','','','','product-top-sharer','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('103','2020-02-17 09:54:48','2020-02-17 09:54:48','twitter_enabled','y','','','','product-top-sharer','','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('104','2021-02-09 13:09:55','2021-02-09 13:09:55','enable_taxes','1','','','','shop','','','','','shop/taxes','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('105','2021-02-09 13:10:25','2021-02-09 13:10:25','enable_coupons','1','','','','shop','','','','','shop/coupons','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('106','2021-02-10 11:37:29','2021-02-09 13:11:00','payment_gw_shop/payments/gateways/pay_on_delivery','','','','','payments','','','','','shop/payments','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('107','2021-02-10 12:10:07','2021-02-09 13:11:01','payment_gw_shop/payments/gateways/omnipay_stripe','1','','','','payments','','','','','shop/payments','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('108','2021-02-10 11:38:21','2021-02-10 11:38:21','shipping_weight_units','kg','','','','orders','','','','','shop/shipping/set_units','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('109','2021-02-10 11:39:16','2021-02-10 11:38:52','website_description','Best open source website builder and CMS','','','','website','','','','','settings/group/website','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('110','2021-02-10 11:39:39','2021-02-10 11:39:23','website_keywords','Create a website, Build online store, CMS, Website builder','','','','website','','','','','settings/group/website','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('111','2021-02-10 11:56:48','2021-02-10 11:56:48','is_active','y','','','','multilanguage_settings','','','','','multilanguage/language_settings','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('112','2021-02-10 12:09:55','2021-02-10 12:09:55','shipping_gw_shop/shipping/gateways/pickup','y','','','','shipping','','','','','shop/shipping','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('113','2021-02-10 12:10:03','2021-02-10 12:10:03','payment_gw_shop/payments/gateways/bank_transfer','1','','','','payments','','','','','shop/payments','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('114','2021-02-10 12:10:06','2021-02-10 12:10:06','payment_gw_shop/payments/gateways/paypal_pro','1','','','','payments','','','','','shop/payments','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('115','2021-02-10 14:08:01','2021-02-10 14:08:01','avatar_enabled','y','','','','comments','','','','','comments/settings','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system,option_value_prev) VALUES('116','2021-02-10 14:08:04','2021-02-10 14:08:04','avatar_style','1','','','','comments','','','','','comments/settings','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('1','JBL speaker WI-FI','','10','content','2020-02-13 15:19:14','2020-02-13 15:19:14','59.85','','nQMJBj8fxwPXfFF6ZWn6CWp08n6VtDdsucEZxRov','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('4','JBL speaker WI-FI','','10','content','2020-02-16 20:05:38','2020-02-16 20:05:38','59.85','','RuxtCYRbGmV5Q3V9f9ztEB3BYOazeOfYJVqikbf9','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('14','Apple Computer','','11','content','2020-02-17 14:55:01','2020-02-17 14:55:01','305.99','','V2HIkzaREdU64guxXHk6OZlGkQMHDWksQ95BEj9n','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('15','Camera','','15','content','2020-02-17 14:55:23','2020-02-17 14:55:23','19.0','','V2HIkzaREdU64guxXHk6OZlGkQMHDWksQ95BEj9n','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('16','JBL speaker WI-FI','','10','content','2020-02-17 15:59:27','2020-02-17 15:59:27','59.85','','QKDJp5owQQARLDYAEmvQSYVADDLrZyQOjyyclZBK','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('17','JBL speaker WI-FI','','10','content','2020-02-17 15:59:49','2020-02-17 15:59:49','59.85','','oAd0kU5VGzEQByLpMnYxY3xXkyyJnaQfw9CxeVt6','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('18','Apple Computer','','11','content','2020-02-17 16:00:04','2020-02-17 16:00:04','305.99','','ahZ3xIGRDdH9HnCdZyh1tpctQIQvpMBDtocc6PLz','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('19','Apple Computer','','11','content','2020-02-17 16:11:50','2020-02-17 16:11:50','305.99','','QKDJp5owQQARLDYAEmvQSYVADDLrZyQOjyyclZBK','1','','0','','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('20','Modern Golder Watch','','9','content','2021-02-09 12:45:41','2021-02-09 12:45:30','30.99','','z5j6HBnP6RQzJtZ8riJXpzsG6YKGDuPESCZr6wAP','2','','0','','','1','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('24','Modern Golder Watch','','9','content','2021-02-10 14:49:17','2021-02-10 14:45:59','30.99','','6htQ11gb3YEYCUyURKKBGQ0C2auInlxCKLchZDWK','1','','1','6','','','','null','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,custom_fields_json,item_image,link,description) VALUES('25','JBL speaker WI-FI','','10','content','2021-02-10 14:49:17','2021-02-10 14:46:03','59.85','','6htQ11gb3YEYCUyURKKBGQ0C2auInlxCKLchZDWK','1','','1','6','','','','null','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders (id,updated_at,created_at,order_id,amount,transaction_id,shipping_service,shipping,currency,currency_code,first_name,last_name,email,country,city,state,zip,address,address2,phone,created_by,edited_by,session_id,customer_id,order_completed,is_paid,url,user_ip,items_count,custom_fields_data,payment_gw,payment_verify_token,payment_amount,payment_currency,payment_status,payment_email,payment_receiver_email,payment_name,payment_country,payment_address,payment_city,payment_state,payment_zip,payment_phone,payer_id,payer_status,payment_type,payment_data,order_status,payment_shipping,is_active,rel_id,rel_type,price,other_info,promo_code,skip_promo_code,coupon_id,discount_type,discount_value,taxes_amount) VALUES('3','2021-02-10 13:31:20','2021-02-10 13:31:20','','188.22','','shop/shipping/gateways/country','0.0','USD','','John','Doe','johndoe@microweber.com','Bulgaria','Sofia','Sofia','1000','Cherni Vruh 47','','123456789','','','pBCS7FW85pA1zOsIMpd2EbVur1YpazcZfDay8MoU','','0','','{SITE_URL}en/shop','127.0.0.1','2','','shop/payments/gateways/paypal_pro','3679c84b7bd9318b599a365e129ff4d2','','','','','','','','','','','','','','','','','','','','','','','Additional information message','','','','','','31.37'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders (id,updated_at,created_at,order_id,amount,transaction_id,shipping_service,shipping,currency,currency_code,first_name,last_name,email,country,city,state,zip,address,address2,phone,created_by,edited_by,session_id,customer_id,order_completed,is_paid,url,user_ip,items_count,custom_fields_data,payment_gw,payment_verify_token,payment_amount,payment_currency,payment_status,payment_email,payment_receiver_email,payment_name,payment_country,payment_address,payment_city,payment_state,payment_zip,payment_phone,payer_id,payer_status,payment_type,payment_data,order_status,payment_shipping,is_active,rel_id,rel_type,price,other_info,promo_code,skip_promo_code,coupon_id,discount_type,discount_value,taxes_amount) VALUES('4','2021-02-10 13:31:24','2021-02-10 13:31:24','','188.22','','shop/shipping/gateways/country','0.0','USD','','John','Doe','johndoe@microweber.com','Bulgaria','Sofia','Sofia','1000','Cherni Vruh 47','','123456789','','','pBCS7FW85pA1zOsIMpd2EbVur1YpazcZfDay8MoU','','0','','{SITE_URL}en/shop','127.0.0.1','2','','shop/payments/gateways/paypal_pro','f2d2e1faf1d224a5f421ab2785a6b226','','','','','','','','','','','','','','','','','','','','','','','Additional information message','','','','','','31.37'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders (id,updated_at,created_at,order_id,amount,transaction_id,shipping_service,shipping,currency,currency_code,first_name,last_name,email,country,city,state,zip,address,address2,phone,created_by,edited_by,session_id,customer_id,order_completed,is_paid,url,user_ip,items_count,custom_fields_data,payment_gw,payment_verify_token,payment_amount,payment_currency,payment_status,payment_email,payment_receiver_email,payment_name,payment_country,payment_address,payment_city,payment_state,payment_zip,payment_phone,payer_id,payer_status,payment_type,payment_data,order_status,payment_shipping,is_active,rel_id,rel_type,price,other_info,promo_code,skip_promo_code,coupon_id,discount_type,discount_value,taxes_amount) VALUES('6','2021-02-10 14:46:39','2021-02-10 14:46:39','','109.008','','shop/shipping/gateways/country','0.0','USD','','John','Doe','john@testmail.com','Bulgaria','Sofia','Sofia','1000','Cherni Vruh 47','','123456789','','','BeGNeBURZlatv8EhMwpHt86Qid0LzgdMRmKLfvon','','1','','{SITE_URL}en/shop','127.0.0.1','2','','shop/payments/gateways/bank_transfer','fe331c98c58db0b835860420c1494500','109.008','USD','','','','','','','','','','','','','','','new','','','','','','Additional information message','','','','','','18.168'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_shipping (id,updated_at,created_at,is_active,shipping_cost,shipping_cost_max,shipping_cost_above,shipping_country,position,shipping_type,shipping_price_per_size,shipping_price_per_weight,shipping_price_per_item,shipping_price_custom) VALUES('2','2021-02-10 12:06:46','2021-02-10 12:06:46','1','0.0','','','Worldwide','','fixed','0.0','0.0','0.0',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */customers (id,user_id,company_id,currency_id,created_at,updated_at,name,first_name,last_name,email,phone,active) VALUES('2','','','','2021-02-10 13:31:43','2021-02-10 13:31:43','John','John','Doe','johndoe@microweber.com','123456789',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('1','*','*','Login'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('2','*','*','Update your browser'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('3','*','*','Signing in...'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('4','*','*','Page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('5','*','*','Post'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('6','*','*','Category'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('7','*','*','Manage Website'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('8','*','*','Manage Modules'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('9','*','*','File Manager'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('10','*','*','Go to Marketplace'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('11','*','*','Updates'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('12','*','*','Suggest a feature'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('13','*','*','Username'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('14','*','*','Username or Email'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('15','*','*','Password'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('16','*','*','Language'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('17','*','*','Back to My WebSite'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('18','*','*','Forgot my password'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('19','*','*','Open-source website builder and CMS'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('20','*','*','Please drag items here'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('21','*','*','Click to select this item'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('22','*','*','Are you sure you want to delete this element'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('23','*','*','Unique visitors'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('24','*','*','All views'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('25','*','*','Date'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('26','*','*','Sunday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('27','*','*','Monday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('28','*','*','Tuesday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('29','*','*','Wednesday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('30','*','*','Thursday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('31','*','*','Friday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('32','*','*','Saturday'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('33','*','*','Sun'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('34','*','*','Mon'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('35','*','*','Tue'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('36','*','*','Wed'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('37','*','*','Thu'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('38','*','*','Fri'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('39','*','*','Sat'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('40','*','*','January'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('41','*','*','February'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('42','*','*','March'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('43','*','*','April'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('44','*','*','May'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('45','*','*','June'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('46','*','*','July'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('47','*','*','August'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('48','*','*','September'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('49','*','*','October'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('50','*','*','November'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('51','*','*','December'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('52','*','*','Jan'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('53','*','*','Feb'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('54','*','*','Mar'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('55','*','*','Apr'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('56','*','*','Aug'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('57','*','*','Sept'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('58','*','*','Oct'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('59','*','*','Nov'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('60','*','*','Dec'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('61','*','*','OK'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('62','*','*','Published'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('63','*','*','Unpublished'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('64','*','*','Content is unpublished'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('65','*','*','Content is published'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('66','*','*','Save'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('67','*','*','Saving'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('68','*','*','Saved'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('69','*','*','Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('70','*','*','Cancel'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('71','*','*','Remove'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('72','*','*','Close'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('73','*','*','Are you sure you want to delete this comment'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('74','*','*','Are you sure you want to delete this?'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('75','*','*','Save &amp; Continue'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('76','*','*','Leave without saving'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('77','*','*','Your session has expired'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('78','*','*','Please login to continue'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('79','*','*','More'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('80','*','*','Template settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('81','*','*','Less'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('82','*','*','Your product is added to cart'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('83','*','*','No results for'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('84','*','*','Switch to Modules'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('85','*','*','Switch to Layouts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('86','*','*','Loading'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('87','*','*','Edit'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('88','*','*','Change'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('89','*','*','Submit'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('90','*','*','Settings are saved'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('91','*','*','Add new image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('92','*','*','You have unsaved changes'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('93','*','*','You have unsaved changes! Are you sure'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('94','*','*','You are logged in'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('95','*','*','Product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('96','*','*','Shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('97','*','*','Edit order'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('98','*','*','Add order'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('99','*','*','Add New'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('100','*','*','New order'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('101','*','*','Comments'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('102','*','*','Notifications'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('103','*','*','Website'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('104','*','*','Live Edit'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('105','*','*','Dashboard'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('106','*','*','Pages'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('107','*','*','Add new page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('108','*','*','Posts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('109','*','*','Add new post'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('110','*','*','Products'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('111','*','*','Add new product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('112','*','*','Categories'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('113','*','*','Add new category'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('114','*','*','Orders'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('115','*','*','Clients'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('116','*','*','Modules'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('117','*','*','Marketplace'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('118','*','*','Users'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('119','*','*','Log out'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('120','*','*','Quick Links'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('121','*','*','View Orders'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('122','*','*','show less'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('123','*','*','show more'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('124','*','*','Referrers'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('125','*','*','Content'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('126','*','*','Visitors'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('127','*','*','Locations'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('128','*','*','Browser language'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('129','*','*','Statistics'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('130','*','*','Daily'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('131','*','*','Weekly'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('132','*','*','Monthly'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('133','*','*','Yearly'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('134','*','*','Views'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('135','*','*','Show more'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('136','*','*','Recent Messages'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('137','*','*','View all'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('138','*','*','Fields'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('139','*','*','See all messages'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('140','*','*','Recent Orders'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('141','*','*','New orders'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('142','*','*','Add new order'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('143','*','*','Unpaid'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('144','*','*','h'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('145','*','*','View order'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('146','*','*','Customer Information'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('147','*','*','Client name'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('148','*','*','E-mail'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('149','*','*','Phone'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('150','*','*','Payment Information'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('151','*','*','Amount'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('152','*','*','Payment method'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('153','*','*','Shipping Information'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('154','*','*','Shipping method'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('155','*','*','Shipping to country'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('156','*','*','Address'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('157','*','*','See all orders'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('158','*','*','Last comments'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('159','*','*','New comments'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('160','*','*','See all comments'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('161','*','*','3 weeks ago'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('162','*','*','View article'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('163','*','*','Status'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('164','*','*','Unpublish'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('165','*','*','Mark as Spam'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('166','*','*','Delete'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('167','*','*','says'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('168','*','*','Comment'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('169','*','*','Add a new comment'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('170','*','*','Reply to'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('171','*','*','Post Comment'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('172','*','*','Open'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('173','*','*','Search'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('174','*','*','Trash'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('175','*','*','Changes are saved'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('176','*','*','Back'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('177','*','*','Are you sure you want to publish this content?'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('178','*','*','Are you sure you want to unpublish this content?'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('179','*','*','Are you sure you want to delete the selected posts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('180','*','*','Do you want to delete this post'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('181','*','*','My Shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('182','*','*','Add Product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('183','*','*','search by keyword'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('184','*','*','search by tags'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('185','*','*','Check all'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('186','*','*','Bulk actions'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('187','*','*','Move to category'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('188','*','*','Sort By'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('189','*','*','Title'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('190','*','*','Editing product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('191','*','*','title'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('192','*','*','Description'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('193','*','*','Pictures'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('194','*','*','Pricing'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('195','*','*','Price'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('196','*','*','Inventory'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('197','*','*','SKU'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('198','*','*','Stock Keeping Unit'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('199','*','*','Barcode'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('200','*','*','ISBN, UPC, GTIN, etc.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('201','*','*','Track quantity'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('202','*','*','Continue selling when out of stock'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('203','*','*','Quantity'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('204','*','*','Available'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('205','*','*','How many products you have available in stock'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('206','*','*','No Limit'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('207','*','*','Out of stock'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('208','*','*','Other'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('209','*','*','Max quantity per order'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('210','*','*','How many products can be ordered at once'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('211','*','*','Shipping'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('212','*','*','This is a physical product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('213','*','*','Fixed Cost'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('214','*','*','Used to set your shipping price at checkout and label prices during fulfillment.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('215','*','*','Weight'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('216','*','*','Used to calculate shipping rates at checkout and label prices during fulfillment.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('217','*','*','kg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('218','*','*','lb'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('219','*','*','oz'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('220','*','*','g'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('221','*','*','Free Shipping'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('222','*','*','Yes'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('223','*','*','No'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('224','*','*','Show advanced weight settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('225','*','*','Advanced'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('226','*','*','Advanced product shipping settings.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('227','*','*','Width'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('228','*','*','Height'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('229','*','*','Depth'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('230','*','*','Show parameters in checkout page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('231','*','*','Show'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('232','*','*','Content saved!'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('233','*','*','Visibility'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('234','*','*','Set a specific publish date'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('235','*','*','Created on'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('236','*','*','updated on'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('237','*','*','Manage'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('238','*','*','Want to add the'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('239','*','*','in more categories'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('240','*','*','Add to'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('241','*','*','Tags'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('242','*','*','Tags/Labels for this content. Use comma (,) to add multiple tags'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('243','*','*','Add media from'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('244','*','*','Add image from URL'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('245','*','*','Browse uploaded'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('246','*','*','Choose from Unsplash'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('247','*','*','Upload file'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('248','*','*','The image is added to the gallery'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('249','*','*','selected'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('250','*','*','Download'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('251','*','*','Image Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('252','*','*','Drop here'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('253','*','*','Image title'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('254','*','*','featured image'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('255','*','*','Update'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('256','*','*','Add file'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('257','*','*','or drop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('258','*','*','Special price must be less than the original price!'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('259','*','*','Make offer price for product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('260','*','*','Offer Price'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('261','*','*','Custom fields'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('262','*','*','Field'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('263','*','*','close'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('264','*','*','Add new field'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('265','*','*','Text Field'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('266','*','*','Single Choice'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('267','*','*','Dropdown'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('268','*','*','Multiple choices'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('269','*','*','Number'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('270','*','*','Web Site'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('271','*','*','Country'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('272','*','*','Time'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('273','*','*','File Upload'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('274','*','*','Property'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('275','*','*','Break Line'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('276','*','*','Hidden Field'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('277','*','*','Type'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('278','*','*','Name'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('279','*','*','Value'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('280','*','*','How to use this module?'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('281','*','*','Help'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('282','*','*','Are you sure you want to Reset the content of this page?  All your text will be lost forever!!'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('283','*','*','Content was resetted!'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('284','*','*','Are you sure you want to copy this page?'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('285','*','*','Content was copied'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('286','*','*','Go to the new page?'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('287','*','*','Are you sure you want to delete this'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('288','*','*','Content was sent to Trash'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('289','*','*','Are you sure you want to change the content type'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('290','*','*','Please consider the documentation for more info'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('291','*','*','Are you sure you want to change the content subtype'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('292','*','*','Hide'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('293','*','*','Search engine'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('294','*','*','SEO setttings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('295','*','*','Add a title and description to see how this product might appear in a search engine listing'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('296','*','*','Meta title'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('297','*','*','Title to appear on the search engines results page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('298','*','*','Meta description'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('299','*','*','Meta keywords'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('300','*','*','Separate keywords with a comma and space'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('301','*','*','Type keywords that describe your content - Example: Blog, Online News, Phones for Sale etc'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('302','*','*','OG Images'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('303','*','*','Those images will be shown as a post image at facebook shares'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('304','*','*','If you want to attach a og images, you must upload them to gallery from &rsquo;Add media&rsquo;'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('305','*','*','Advanced settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('306','*','*','advanced settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('307','*','*','Use the advanced settings to customize your blog post'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('308','*','*','Redirect to URL'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('309','*','*','If set this, the user will be redirected to the new URL when visits the page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('310','*','*','http://yoursite.com'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('311','*','*','Require login'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('312','*','*','If set to yes - this page will require login from a registered user in order to be opened'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('313','*','*','Author'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('314','*','*','Related Content'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('315','*','*','You can add related content to your post or product'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('316','*','*','Edit related'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('317','*','*','More options'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('318','*','*','Choose more options'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('319','*','*','Duplicate'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('320','*','*','Delete Content'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('321','*','*','Reset Content'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('322','*','*','Content type'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('323','*','*','Warning!'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('324','*','*','Do not change these settings unless you know what you are doing.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('325','*','*','Change content type'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('326','*','*','Changing the content type to different than'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('327','*','*','is advanced action. Please read the documentation and consider not to change the content type'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('328','*','*','Change content sub type'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('329','*','*','Best product labels examples are: Sale, Promo, Top Offer etc.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('330','*','*','Label'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('331','*','*','Label Color'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('332','*','*','Separate options with a comma'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('333','*','*','Use &rsquo;.&rsquo; to separate the price (Ex. 9.89)'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('334','*','*','Website settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('335','*','*','General'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('336','*','*','Make basic settings for your website'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('337','*','*','Check for the latest updates'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('338','*','*','Email settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('339','*','*','Template'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('340','*','*','Change or manage the theme you use'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('341','*','*','Additional settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('342','*','*','Files'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('343','*','*','File management'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('344','*','*','Login & Register'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('345','*','*','Manage the access control to your website'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('346','*','*','Choice of language and translations'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('347','*','*','Privacy Policy'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('348','*','*','Privacy Policy and GDPR settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('349','*','*','Shop settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('350','*','*','Basic store settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('351','*','*','Coupons'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('352','*','*','Creating and managing coupon codes'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('353','*','*','Delivery methods and suppliers'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('354','*','*','Promotions'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('355','*','*','Creating and managing promo campaigns'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('356','*','*','Payments'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('357','*','*','Select and set up a payment provider'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('358','*','*','Taxes'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('359','*','*','Fees and tax rates'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('360','*','*','Invoices'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('361','*','*','Invoice lists and accounting'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('362','*','*','Auto respond mail'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('363','*','*','Email and message settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('364','*','*','Other settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('365','*','*','Other shop settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('366','*','*','Users must agree to Terms and Conditions'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('367','*','*','Purchasing requires registration'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('368','*','*','Require fields for checkout'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('369','*','*','First Name'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('370','*','*','Last Name'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('371','*','*','Email'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('372','*','*','City'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('373','*','*','State'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('374','*','*','Zip'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('375','*','*','Checkout URL'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('376','*','*','Use default'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('377','*','*','Custom order id'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('378','*','*','Online shop status'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('379','*','*','Choose the status of your online shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('380','*','*','Enable'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('381','*','*','Disable'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('382','*','*','Shipping units are saved!'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('383','*','*','Shipping units'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('384','*','*','Select in which units the transport shipment will be calculated'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('385','*','*','Units for weight'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('386','*','*','kilograms (kg)'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('387','*','*','pound (lb)'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('388','*','*','Units for size'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('389','*','*','centimeters (cm)'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('390','*','*','inches (in)'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('391','*','*','Seo Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('392','*','*','Fill in the fields for maximum results when finding your website in search engines.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('393','*','*','Website Name'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('394','*','*','This is very important for search engines.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('395','*','*','Your website will be categorized by many criteria and its name is one of them.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('396','*','*','Website Description'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('397','*','*','Describe what your website is about'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('398','*','*','Website Keywords'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('399','*','*','Ex.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('400','*','*','Cat, Videos of Cats, Funny Cats, Cat Pictures, Cat for Sale, Cat Products and Food'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('401','*','*','Permalink Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('402','*','*','Choose the URL posts & page format.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('403','*','*','General Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('404','*','*','Set regional settings for your website or online store'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('405','*','*','They will also affect the language you use and the fees for the orders.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('406','*','*','Date Format'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('407','*','*','Choose a date format for your website'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('408','*','*','Time Zone'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('409','*','*','Change Favicon'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('410','*','*','Select an icon for your website. It is best to be part of your logo.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('411','*','*','Upload favicon'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('412','*','*','Posts per Page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('413','*','*','Select how many posts or products you want to be shown per page'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('414','*','*','Fonts'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('415','*','*','Select fonts you want to install for your website.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('416','*','*','Social Networks links'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('417','*','*','Add links to your social media accounts. Once set up, you can use them anywhere on your site using the "social networks" module with drag and drop technology.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('418','*','*','Online Shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('419','*','*','Enable or disable your online shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('420','*','*','Maintenance mode'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('421','*','*','All changes are saved'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('422','*','*','Social Links'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('423','*','*','Select and type socials links you want to show'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('424','*','*','Select the social networks you want to see on your site, blog and store'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('425','*','*','Turn on Under construction mode of your site'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('426','*','*','Advanced settings updated'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('427','*','*','The DB was reloaded'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('428','*','*','SEO Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('429','*','*','Make these settings to get the best results when finding your website.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('430','*','*','Development settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('431','*','*','If you are developer you will find great tools to make your website.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('432','*','*','Other settings for your website.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('433','*','*','Internal Settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('434','*','*','Internal settings for developers'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('435','*','*','Internal settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('436','*','*','Live Edit settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('437','*','*','Configure Live Edit settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('438','*','*','Setup statitics'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('439','*','*','Configure website statistics'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('440','*','*','Statistics settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('441','*','*','Reload Database'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('442','*','*','Experimental'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('443','*','*','Actions'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('444','*','*','Experimental settings for developers'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('445','*','*','Experimental settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('446','*','*','Google'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('447','*','*','If you have a Google Tag Manager account, you can verify ownership of a site using your Google Tag Manager container snippet code. To verify ownership using Google Tag Manager: Choose Google Tag Manager in the verification details page for your site, and follow the instructions shown.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('448','*','*','Read the article here.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('449','*','*','Google Analytics ID'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('450','*','*','Google Analytics&rsquo; property ID is the identifier associated with your account and used by Google Analytics to collect the data.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('451','*','*','How to find it read here.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('452','*','*','Facebook pixel ID'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('453','*','*','You can find a tutorials in internet where and how to find the code.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('454','*','*','Other search engines'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('455','*','*','Bing'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('456','*','*','Alexa'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('457','*','*','Pinterest'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('458','*','*','Site verification code for'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('459','*','*','Yandex'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('460','*','*','Custom head tags'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('461','*','*','Advanced functionality'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('462','*','*','You can put custom html in the site head-tags. Please put only valid meta tags or you can break your site.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('463','*','*','Custom footer tags'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('464','*','*','You can put custom html in the site footer-tags. Please put only valid meta tags or you can break your site.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('465','*','*','content'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('466','*','*','The robots. txt file, also known as the robots exclusion protocol or standard, is a text file that tells web robots (most often search engines) which pages on your site to crawl. It also tells web robots which pages not to crawl.'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('467','*','*','Developers tools'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('468','*','*','If you are a developer, then these tools would be useful to you'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('469','*','*','Template Backup'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('470','*','*','Make a backup of your template website'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('471','*','*','Export template'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('472','*','*','Media cleanup'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('473','*','*','This module will remove media from database, which is not present on the hard drive'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('474','*','*','Cleanup the images'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('475','*','*','Database cleanup'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('476','*','*','This module will remove categories, images and custom fields which are connected to a content that is manually deleted from the database'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('477','*','*','Show system log'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('478','*','*','Show sistem logs for the last 30 days'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('479','*','*','Licenses'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('480','*','*','Add or edit your licenses'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('481','*','*','Cache settings'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('482','*','*','Speed up your website load speed'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('483','*','*','The cache was cleared'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('484','*','*','Clear cache'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('485','*','*','Available Backups'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('486','*','*','Filename'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('487','*','*','Size'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */translation_keys (id,translation_namespace,translation_group,translation_key) VALUES('488','*','*','export progress'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('1','iwatch','Iwatch','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('2','apple','Apple','2','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('3','watch','Watch','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('4','jbl','Jbl','2','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('5','speakers','Speakers','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('6','computer','Computer','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('7','speaker','Speaker','3','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('8','amazon','Amazon','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('9','camera','Camera','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('10','accessoaries','Accessoaries','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('11','diving','Diving','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('12','islands','Islands','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('13','travel','Travel','2','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('14','usa','Usa','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('15','west','West','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('16','yacht','Yacht','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('17','summer','Summer','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('18','sea','Sea','1','','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */tagging_tags (id,slug,name,count,tag_group_id,description,suggest) VALUES('19','world','World','1','','','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments (id,updated_at,created_at,created_by,edited_by,comment_body,is_moderated,is_new,is_sent_email,is_subscribed_for_notification,rel_type,rel_id,session_id,comment_name,comment_email,comment_website,from_url,comment_subject,is_spam,for_newsletter,user_ip,reply_to_comment_id) VALUES('1','2021-02-10 14:44:08','2021-02-10 14:44:08','','','<p>Very good article. This is test comment from the blog on this article.</p>
','1','','','','content','20','BeGNeBURZlatv8EhMwpHt86Qid0LzgdMRmKLfvon','John Doe','john@testmail.com','','{SITE_URL}en/around-the-world','','','','127.0.0.1',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */multilanguage_supported_locales (id,locale,language,display_locale,display_name,display_icon,position,is_active) VALUES('1','en','English','','','','1','y'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_coupons (id,coupon_name,coupon_code,discount_type,discount_value,total_amount,uses_per_coupon,uses_per_customer,is_active) VALUES('2','Microweber','5f612dbb','percentage','5','1','100','100','1'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */testimonials (id,name,content,read_more_url,created_on,project_name,client_company,client_role,client_picture,client_website,position) VALUES('1','John Doe','Wow Microweber is realy great website builder, I love it!I was able to create a website my-self in very easy way. I deffenately recommend it to all my
friends and colegues to us it and make their own website or online store for free.Thank you!','','','Testimonials','','CEO and Marketing','{SITE_URL}userfiles/media/templates.microweber.com/testimonial.png','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */testimonials (id,name,content,read_more_url,created_on,project_name,client_company,client_role,client_picture,client_website,position) VALUES('2','Jena Armstrong','Wow Microweber is realy great website builder, I love it!I was able to create a website my-self in very easy way. I deffenately recommend it to all my
friends and colegues to us it and make their own website or online store for free.Thank you!','','','Testimonials','','Life coach, Healty Life','{SITE_URL}userfiles/media/templates.microweber.com/athenathemes-tribe-10.png','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */testimonials (id,name,content,read_more_url,created_on,project_name,client_company,client_role,client_picture,client_website,position) VALUES('3','Natalia Aklim','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.','','','Opinions','','','{SITE_URL}userfiles/media/templates.microweber.com/team3.jpg','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */testimonials (id,name,content,read_more_url,created_on,project_name,client_company,client_role,client_picture,client_website,position) VALUES('4','Ivan Gerjovich','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.','','','Opinions','','','{SITE_URL}userfiles/media/templates.microweber.com/team1_1.jpg','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */testimonials (id,name,content,read_more_url,created_on,project_name,client_company,client_role,client_picture,client_website,position) VALUES('5','Jonatan Joew','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.','','','Opinions','','','{SITE_URL}userfiles/media/templates.microweber.com/team2.jpg','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */testimonials (id,name,content,read_more_url,created_on,project_name,client_company,client_role,client_picture,client_website,position) VALUES('6','John Doe','It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.','','','Opinions','','','{SITE_URL}userfiles/media/templates.microweber.com/team6.jpg','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('1','nDd8WfLlrYlasCxj4CYMQjV6tp6IYANdPeGqolLz','','94.26.57.98','0','1','0','','','1','bg','2020-01-21 10:30:11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('2','8THwFFrdQlme0Zx4eCXvMkPAWAPcv2bycb46kUnS','','94.26.57.98','1','1','0','','','1','bg','2020-01-21 10:34:43'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('3','pXmPrJ3PWaPcMmWQJVtNvDQEAAoWfJysS1lMKva7','','94.26.57.98','0','1','0','','','1','bg','2020-01-21 13:39:09'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('4','Xo61KNi9tSGd88QUkV7v7rIcxKv8NevXNdTCt2K2','','94.26.57.98','0','2','0','','','1','en','2020-01-21 13:46:34'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('5','wPnC3ASnldWsQ3wnRESWiWaHkt7cR4ntSyrizrR9','','94.26.57.98','1','1','0','','','1','bg','2020-01-21 14:08:35'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('6','ZhOpKyt6cQO1aPjhasTjdS7jALx1L5wht1VU7yE8','','94.26.57.98','0','1','0','','','1','bg','2020-01-22 13:01:42'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('7','JcTKJIc7gAhukOZ8W0Vx2PwqkAB6XaZ0gGzL50oa','','82.146.26.228','0','4','0','','','1','en','2020-01-22 13:02:10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('8','SuJYK6SiQitWrgCYT66c7aaf3ZoUPodEnvvTHOLg','','94.26.57.98','0','5','0','','','1','en','2020-01-22 13:02:33'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('9','nytYy49biS6Y50ynIKVEX12AxkrYwc23aBPN1n2l','','87.126.60.140','0','6','0','','','1','en','2020-01-22 13:02:59'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('10','3rzVEWbUEnMrzkT574AjOqIZvdHQ0D3kFNZfu8UH','','94.26.57.98','1','1','2','1','2','1','bg','2020-01-22 14:10:42'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('11','56RdCdIypQsUDZ7MbSxJC0yFGZ9kefW9Y14r57MO','','94.26.57.98','0','2','0','','','1','en','2020-01-22 14:11:29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('12','R1DPd59KQJz6M0829xbT49dJ6sFRII5Z0wAmmlbg','','94.26.57.98','0','1','0','','','1','bg','2020-01-23 08:23:07'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('13','7YekIZ1wCtljQnBW4rNpXwiWc7TGAQanomozaBzF','','94.26.57.98','0','2','0','','','1','en','2020-01-23 11:13:34'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('14','m9mZLTgeUOLMtaQylW9Gi3KpARl34vT3zG6O3afo','','94.26.57.98','0','1','0','','','1','bg','2020-01-23 11:40:47'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('15','1N2RSND3MFis9EpSMc3MU1DLYrva9JtpO0b1u0J5','','94.26.57.98','0','1','0','','','1','bg','2020-01-27 10:40:38'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('16','DvNSQgWlC29Ll0OMK5lG7THloBYqjX0pCpzqQ44n','','94.26.57.98','1','1','3','1','3','1','bg','2020-01-27 10:46:38'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('17','5FbHgmuwPP7jqTnfw2wlf993YR5i9PeYEdxgGnWF','','94.26.57.98','0','1','0','','','1','bg','2020-01-27 11:43:30'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('18','fcjWsFRCfHTr9hOjC7a5mqkF1a5mIUD69ceRO5uA','','94.26.57.98','0','1','0','','','1','bg','2020-01-27 11:44:15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('19','XcIFkhZM1POx2EpkJzBqB2NR1fXI7B3YFNoNh0eh','','94.26.57.98','0','7','0','','','1','en','2020-01-27 12:00:54'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('20','H9zcudC1orqgfr6xQP11sgtq3CbA74BQZnComKA9','','94.26.57.98','0','2','0','','','1','en','2020-01-27 12:21:55'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('21','7QX4hMQ2Kb91W0rvlx6h4kdVW8wJpamBIg3TIKnV','','94.26.57.98','0','2','0','','','1','en','2020-01-28 08:08:23'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('22','8no7jN9IC0VJT4J6rMf07KmjTXVU7LquQDYcdQml','','94.26.57.98','0','8','0','','','1','en','2020-01-28 12:07:40'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('23','624ZIyzxLRHNXDB2XLeoldtdelnSBJFT7Nd5k30S','','94.26.57.98','0','2','0','','','1','en','2020-01-28 12:15:16'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('24','Tb4fTkRcFxGYrj0tYSRvqusJpxpOnkghm2cUQ7Iq','','94.26.57.98','0','1','0','','','1','bg','2020-01-29 11:05:11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('25','7NznkwLYxg6Y5NDEkGedDbYTDblhICHENs7rFLvQ','','94.26.57.98','1','1','0','','','1','bg','2020-01-29 12:24:10'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('26','TTggpaoxo4PIYb9K5e1VEpkV1IOLbg5oTZPMl5V1','','94.26.57.98','0','2','0','','','1','en','2020-01-29 15:00:04'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('27','lg5V5jJP2Nj0rmiGO2JbHsfKS57IfwhV6R3NasiS','','94.26.57.98','0','2','0','','','1','en','2020-01-30 08:34:15'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('28','W0MqHFFzvVH2yqE3jf8KjzYcA3enCxOnCpwysw9Z','','94.26.57.98','0','1','0','','','1','bg','2020-01-30 09:46:44'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('29','pbkxCxYhBnlHEf3vRC2PuMiF0x2olcRBeGJWXJsS','','94.26.57.98','1','1','5','1','5','1','bg','2020-01-30 09:55:16'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('30','8a9rLSTsLssL3Wwxq7g2cCFgyFaebCEUVklk66ET','','78.83.182.218','0','9','0','','','1','en','2020-02-02 12:39:35'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('31','BrDibLvkZLzrJGU7wUz4lxtfcA2eeuCaKuswxxHP','','94.26.57.98','0','1','0','','','1','bg','2020-02-03 11:41:13'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('32','RgTQjQJ1ZByfhYmSiMeocpDNrp6cIOrTh1XBppi3','','94.26.57.98','0','1','0','','','1','bg','2020-02-04 13:00:26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('33','2JdK8hHpJhFUiJKzhACzm3hNlSUiajbMCnbZNvsS','','94.26.57.98','1','1','1','1','1','1','bg','2020-02-04 14:01:49'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('34','tSpYOhyCZgb3pHDBXAVBCvWm5JkPeGtSs0ctZn4E','','94.26.57.98','0','2','0','','','1','en','2020-02-05 09:14:03'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('35','miUTCwFZsySrf0NE7vsXaPJSlFgjr2kQlBkcPPhW','','94.26.57.98','0','1','0','','','1','bg','2020-02-05 11:23:52'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('36','riEiOw3bODTyD43y7X8taaYIJFAMo0lAQvNT1BTg','','94.26.57.98','1','1','0','','','1','bg','2020-02-05 12:09:26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('37','KNQtvcpUXJMiBKIkrSozCoxIK316dzswxVIgPXES','','94.26.57.98','0','2','0','','','1','en','2020-02-05 14:12:53'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('38','8gjOfkLin8bE6IR3u2ZvRFvjEfTUz5t6vkDzCaGz','','94.26.57.98','0','1','0','','','1','bg','2020-02-06 09:32:00'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('39','osAbMP8zoz0JCydRdC1wO2gAPE41kf5pXcFKoDWA','','94.26.57.98','0','2','0','','','1','en','2020-02-10 10:37:47'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('40','E9BLVQcOyAwiBd5WJAX5k66ZCKV8LM4HRGcqDFLU','','94.26.57.98','0','2','0','','','1','en','2020-02-11 08:58:48'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('41','yz3qlAH8lcdSwSV5NMUOJCzsjf5t8MS6ErP0BJr7','','94.26.57.98','0','2','0','','','1','en','2020-02-13 09:08:11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('42','nQMJBj8fxwPXfFF6ZWn6CWp08n6VtDdsucEZxRov','','95.111.95.14','0','10','0','','','1','en','2020-02-13 15:18:34'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('43','KLzjNz5TxpaPpAZD57Xsi0MtonwDFRRFgH6nLTOr','','94.26.57.98','0','1','0','','','1','bg','2020-02-13 15:36:54'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('44','Ie0BGOBLuFcJcMYb8Dq0KAA04ASdmNYPyQA9SERc','','213.112.85.32','0','11','0','','','2','sv','2020-02-13 16:02:53'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('45','rFzLDjrMm0VbKR9E9pfLEkbqkaBdncnvPDyJRA3i','','94.26.57.98','0','1','6','1','6','1','bg','2020-02-14 07:35:57'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('46','340BIUGOYpGnlnKEWsJhjIrNOJoR78TtFDl5ttU6','','94.26.57.98','1','1','11','1','11','1','bg','2020-02-14 07:43:57'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('47','g8zPyIrOBQ260BoXrEqUysGEn5PSAnv6EN3jz6Zx','','94.26.57.98','0','2','0','','','1','en','2020-02-14 15:31:27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('48','RuxtCYRbGmV5Q3V9f9ztEB3BYOazeOfYJVqikbf9','','213.112.85.32','0','11','0','','','2','sv','2020-02-16 20:00:21'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('49','AACEh5cbNPXyg0oQ1eJ2cS6DLID7WZU3GLMpSFx1','','213.112.85.32','0','11','0','','','2','sv','2020-02-16 23:34:42'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('50','EjIPuux0eriqkpo6RdhuDnN1t2a1WN5D1bTc7swK','','94.26.57.98','0','1','0','','','1','bg','2020-02-17 08:29:14'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('51','IVMvLPCGtBaAtGfgaj27YIgDlvk14VSmrf45Fgn9','','94.26.57.98','1','1','0','','','1','bg','2020-02-17 08:29:42'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('52','QKDJp5owQQARLDYAEmvQSYVADDLrZyQOjyyclZBK','','94.26.57.98','0','2','0','','','1','en','2020-02-17 08:44:17'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('53','42ekNRFusdgWEuerVUK6DkOpB6vOwlcAa20MZdBA','','94.26.57.98','0','1','0','','','1','bg','2020-02-17 11:29:42'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('54','oAd0kU5VGzEQByLpMnYxY3xXkyyJnaQfw9CxeVt6','','94.26.57.98','0','2','9','1','9','1','en','2020-02-17 14:29:59'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('55','5UDKwHDa2Zze7tdzXfGGH7yrBaN5oHumZNvmypiD','','94.26.57.98','0','12','0','','','1','en','2020-02-17 14:51:29'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('56','V2HIkzaREdU64guxXHk6OZlGkQMHDWksQ95BEj9n','','94.26.57.98','0','5','0','','','1','en','2020-02-17 14:54:50'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('57','XwfZOmaUZ3tllYnFOzohW94U1npMGUmYH0LrHfto','','87.126.60.140','0','1','0','','','1','en','2020-02-17 15:03:09'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('58','ahZ3xIGRDdH9HnCdZyh1tpctQIQvpMBDtocc6PLz','','94.26.57.98','0','13','0','','','1','bg','2020-02-17 15:59:50'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('59','iAtz8DGWQrgEajaMpJst5YGScDFzoW7UYoiu7xqy','','173.252.127.51','0','14','25','2','','3','en','2020-02-17 19:05:25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('60','ppC9ZbcGT0w56rrWP3yDZWSUUKPrWsK5pRGwnWWA','','94.26.57.98','0','2','0','','','1','en','2020-02-18 10:25:54'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('61','NOvrbgm8TDzvBNWiwOO7bqz08RHlUgfYmefB2uVL','','94.26.57.98','0','13','0','','','1','bg','2020-02-18 12:49:35'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('62','z5j6HBnP6RQzJtZ8riJXpzsG6YKGDuPESCZr6wAP','','127.0.0.1','1','1','1','1','1','4','en','2021-02-09 12:40:55'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('63','6PxAvrtTMg0GDmhVD3xWIdKXY8BCF8T673Gz27P9','','127.0.0.1','0','1','5','1','5','4','en','2021-02-10 11:16:48'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('64','VxBFmvMst9TCTu9m93nKPNOGHXgT7CJla0JWLArs','','127.0.0.1','1','1','2','1','2','4','en','2021-02-10 11:18:36'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('65','WMXZcsdKkn2QMXSwhsJcG4daxXZukl2bLI4JUl6A','','127.0.0.1','1','1','8','1','8','4','en','2021-02-10 12:40:53'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('66','pBCS7FW85pA1zOsIMpd2EbVur1YpazcZfDay8MoU','','127.0.0.1','2','1','9','1','9','4','en','2021-02-10 12:55:28'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('67','wSsiYqj16NuTN09FMctzwPzKdXQj5bTawGvNr9RJ','','127.0.0.1','0','1','8','1','8','4','en','2021-02-10 14:05:26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_sessions (id,session_id,session_hostname,user_ip,user_id,browser_id,referrer_id,referrer_domain_id,referrer_path_id,geoip_id,language,updated_at) VALUES('68','BeGNeBURZlatv8EhMwpHt86Qid0LzgdMRmKLfvon','','127.0.0.1','0','1','5','1','5','4','en','2021-02-10 14:43:12'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_geoip (id,country_code,country_name,region,city,latitude,longitude,updated_at) VALUES('1','BG','Bulgaria','','','','','2020-01-21 10:30:11'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_geoip (id,country_code,country_name,region,city,latitude,longitude,updated_at) VALUES('2','SE','Sweden','','','','','2020-02-13 16:02:53'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_geoip (id,country_code,country_name,region,city,latitude,longitude,updated_at) VALUES('3','US','United States','','','','','2020-02-17 19:05:25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */stats_geoip (id,country_code,country_name,region,city,latitude,longitude,updated_at) VALUES('4','unknown','unknown','','','','','2021-02-09 12:40:55'); /* MW_QUERY_SEPERATOR */





